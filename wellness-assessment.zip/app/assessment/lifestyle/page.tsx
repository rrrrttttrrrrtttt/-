"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight } from "lucide-react"

export default function LifestyleAssessmentPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})

  const questions = [
    {
      id: "exercise",
      question: "您每周进行有氧运动（如快走、游泳、骑车）的频率是？",
      options: [
        { value: "1", label: "几乎不运动" },
        { value: "2", label: "每周1-2次" },
        { value: "3", label: "每周3-4次" },
        { value: "4", label: "每周5次以上" },
      ],
    },
    {
      id: "diet",
      question: "您的饮食结构如何？",
      options: [
        { value: "1", label: "不规律，常吃快餐或加工食品" },
        { value: "2", label: "基本规律，但营养不均衡" },
        { value: "3", label: "规律且较为均衡" },
        { value: "4", label: "非常规律，营养均衡全面" },
      ],
    },
    {
      id: "water",
      question: "您每天的饮水量是？",
      options: [
        { value: "1", label: "少于500ml" },
        { value: "2", label: "500-1000ml" },
        { value: "3", label: "1000-1500ml" },
        { value: "4", label: "1500ml以上" },
      ],
    },
    {
      id: "smoking",
      question: "您是否吸烟？",
      options: [
        { value: "1", label: "每天吸烟" },
        { value: "2", label: "偶尔吸烟" },
        { value: "3", label: "已戒烟" },
        { value: "4", label: "从不吸烟" },
      ],
    },
    {
      id: "alcohol",
      question: "您的饮酒情况是？",
      options: [
        { value: "1", label: "经常饮酒（每周多次）" },
        { value: "2", label: "适量饮酒（每周1-2次）" },
        { value: "3", label: "偶尔饮酒（社交场合）" },
        { value: "4", label: "几乎不饮酒" },
      ],
    },
  ]

  const currentQuestion = questions[currentStep]
  const progress = ((currentStep + 1) / questions.length) * 100

  const handleAnswer = (value: string) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }))
  }

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      // Save answers and proceed to next section
      localStorage.setItem("lifestyleAssessment", JSON.stringify(answers))
      router.push("/assessment/mental")
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    } else {
      router.push("/assessment/physical")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex justify-between items-center mb-2">
            <CardTitle className="text-xl font-bold text-primary">生活习惯评估</CardTitle>
            <span className="text-sm text-muted-foreground">
              {currentStep + 1}/{questions.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
          <CardDescription className="pt-2">请根据您的实际情况选择最符合的选项</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-lg font-medium">{currentQuestion.question}</div>

          <RadioGroup value={answers[currentQuestion.id] || ""} onValueChange={handleAnswer} className="space-y-3">
            {currentQuestion.options.map((option) => (
              <div
                key={option.value}
                className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 transition-colors"
              >
                <RadioGroupItem value={option.value} id={`option-${option.value}`} />
                <Label htmlFor={`option-${option.value}`} className="flex-grow cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handlePrevious}>
            <ArrowLeft className="mr-2 h-4 w-4" /> 上一步
          </Button>
          <Button onClick={handleNext} disabled={!answers[currentQuestion.id]}>
            {currentStep < questions.length - 1 ? "下一题" : "下一部分"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

