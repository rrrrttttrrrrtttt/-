"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

export default function IntroPage() {
  const router = useRouter()
  const [agreed, setAgreed] = useState(false)

  const handleStart = () => {
    if (agreed) {
      router.push("/assessment/basic-info")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold text-primary">测试说明</CardTitle>
          <CardDescription>在开始测试前，请了解以下信息</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3 text-sm">
            <p>
              • 本测试大约需要<span className="font-medium">10分钟</span>完成
            </p>
            <p>• 请在安静、不受干扰的环境中完成测试</p>
            <p>• 测试结果仅供参考，不构成医疗诊断</p>
            <p>• 您的数据将被安全保存，仅用于生成个性化报告</p>
          </div>

          <div className="flex items-center space-x-2 pt-4">
            <Checkbox id="terms" checked={agreed} onCheckedChange={(checked) => setAgreed(checked === true)} />
            <Label htmlFor="terms" className="text-sm">
              我已阅读并同意《用户协议》和《隐私政策》
            </Label>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" size="lg" onClick={handleStart} disabled={!agreed}>
            继续
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

