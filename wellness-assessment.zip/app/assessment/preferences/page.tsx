"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight } from "lucide-react"

export default function PreferencesAssessmentPage() {
  const router = useRouter()
  const [answers, setAnswers] = useState<Record<string, string[]>>({
    interests: [],
    activities: [],
    environment: [],
    duration: [],
    budget: [],
  })

  const [currentStep, setCurrentStep] = useState(0)

  const questions = [
    {
      id: "interests",
      question: "您对以下哪些康养主题感兴趣？（可多选）",
      options: [
        { value: "tcm", label: "中医养生" },
        { value: "nutrition", label: "营养调理" },
        { value: "fitness", label: "健身塑形" },
        { value: "mental", label: "心理减压" },
        { value: "sleep", label: "睡眠改善" },
        { value: "detox", label: "排毒养颜" },
        { value: "rehabilitation", label: "康复理疗" },
      ],
    },
    {
      id: "activities",
      question: "您希望康养旅行中包含哪些活动？（可多选）",
      options: [
        { value: "yoga", label: "瑜伽/太极" },
        { value: "hiking", label: "户外徒步" },
        { value: "spa", label: "SPA水疗" },
        { value: "meditation", label: "冥想放松" },
        { value: "diet", label: "健康饮食" },
        { value: "massage", label: "专业按摩" },
        { value: "lecture", label: "健康讲座" },
      ],
    },
    {
      id: "environment",
      question: "您偏好的康养环境是？（可多选）",
      options: [
        { value: "mountain", label: "山林环境" },
        { value: "seaside", label: "海滨环境" },
        { value: "hotspring", label: "温泉环境" },
        { value: "countryside", label: "田园环境" },
        { value: "resort", label: "度假酒店" },
        { value: "medical", label: "医疗机构" },
      ],
    },
    {
      id: "duration",
      question: "您理想的康养旅行时长是？",
      options: [
        { value: "weekend", label: "周末2-3天" },
        { value: "week", label: "5-7天" },
        { value: "twoweeks", label: "1-2周" },
        { value: "month", label: "1个月以上" },
      ],
    },
    {
      id: "budget",
      question: "您的康养旅行预算范围是？（人均）",
      options: [
        { value: "low", label: "3000元以下" },
        { value: "medium", label: "3000-5000元" },
        { value: "high", label: "5000-10000元" },
        { value: "premium", label: "10000元以上" },
      ],
    },
  ]

  const currentQuestion = questions[currentStep]
  const progress = ((currentStep + 1) / questions.length) * 100

  const handleCheckboxChange = (value: string, checked: boolean) => {
    setAnswers((prev) => {
      const currentValues = prev[currentQuestion.id] || []

      if (checked) {
        return { ...prev, [currentQuestion.id]: [...currentValues, value] }
      } else {
        return { ...prev, [currentQuestion.id]: currentValues.filter((v) => v !== value) }
      }
    })
  }

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      // Save answers and proceed to results
      localStorage.setItem("preferencesAssessment", JSON.stringify(answers))
      router.push("/assessment/results")
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    } else {
      router.push("/assessment/medication")
    }
  }

  const isCurrentStepValid = () => {
    return (answers[currentQuestion.id] || []).length > 0
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex justify-between items-center mb-2">
            <CardTitle className="text-xl font-bold text-primary">康养需求偏好</CardTitle>
            <span className="text-sm text-muted-foreground">
              {currentStep + 1}/{questions.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
          <CardDescription className="pt-2">请选择您的康养旅行偏好</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-lg font-medium">{currentQuestion.question}</div>

          <div className="space-y-3">
            {currentQuestion.options.map((option) => (
              <div
                key={option.value}
                className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 transition-colors"
              >
                <Checkbox
                  id={`option-${option.value}`}
                  checked={(answers[currentQuestion.id] || []).includes(option.value)}
                  onCheckedChange={(checked) => handleCheckboxChange(option.value, checked === true)}
                />
                <Label htmlFor={`option-${option.value}`} className="flex-grow cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handlePrevious}>
            <ArrowLeft className="mr-2 h-4 w-4" /> 上一步
          </Button>
          <Button onClick={handleNext} disabled={!isCurrentStepValid()}>
            {currentStep < questions.length - 1 ? "下一题" : "查看结果"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

