"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Calendar, MapPin, Clock, Wallet } from "lucide-react"

type TravelPlan = {
  id: string
  title: string
  location: string
  duration: string
  price: string
  tags: string[]
  description: string
  highlights: string[]
  suitableFor: string[]
}

export default function TravelPlansPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [travelPlans, setTravelPlans] = useState<TravelPlan[]>([])
  const [preferences, setPreferences] = useState<Record<string, string[]>>({})

  useEffect(() => {
    // In a real app, this would fetch from an API based on user's assessment
    setTimeout(() => {
      try {
        const preferencesData = JSON.parse(localStorage.getItem("preferencesAssessment") || "{}")
        setPreferences(preferencesData)

        // Generate travel plans based on preferences
        setTravelPlans(generateTravelPlans(preferencesData))
        setLoading(false)
      } catch (error) {
        console.error("Error loading travel plans:", error)
        setLoading(false)
      }
    }, 1000)
  }, [])

  const generateTravelPlans = (preferences: Record<string, string[]>): TravelPlan[] => {
    // This would typically come from a backend API
    // For demo purposes, we'll generate some plans based on preferences

    const plans: TravelPlan[] = [
      {
        id: "plan1",
        title: "山水禅心·养生之旅",
        location: "莫干山",
        duration: "3天2晚",
        price: "¥3,800起/人",
        tags: ["中医养生", "森林疗愈", "冥想放松"],
        description: "位于莫干山深处的禅修康养基地，结合传统中医理念和现代健康科学，为您提供身心全方位的调理体验。",
        highlights: ["中医体质辨识与个性化调理", "森林浴与自然疗愈", "禅修冥想课程", "有机食材健康餐饮"],
        suitableFor: ["压力较大需要放松的都市人群", "对中医养生感兴趣的人士", "需要改善睡眠质量的人群"],
      },
      {
        id: "plan2",
        title: "海滨康复·活力重塑",
        location: "三亚",
        duration: "5天4晚",
        price: "¥6,500起/人",
        tags: ["康复理疗", "水疗SPA", "营养调理"],
        description:
          "三亚五星级度假酒店内的专业康复中心，配备先进的康复设备和专业医疗团队，适合需要专业康复指导的人群。",
        highlights: ["专业康复评估与指导", "海洋水疗与理疗", "个性化营养餐饮计划", "海滨瑜伽与太极课程"],
        suitableFor: ["亚健康状态需要调理的人群", "术后康复期的人士", "需要专业健康指导的中老年人"],
      },
      {
        id: "plan3",
        title: "温泉养心·轻奢之旅",
        location: "黄山",
        duration: "4天3晚",
        price: "¥4,200起/人",
        tags: ["温泉疗养", "养生膳食", "户外徒步"],
        description: "黄山脚下的温泉度假村，结合当地丰富的温泉资源和养生文化，提供全方位的身心调养体验。",
        highlights: ["天然温泉浸泡疗法", "中医经络按摩", "养生膳食工作坊", "黄山轻度徒步"],
        suitableFor: ["关节不适需要改善的人群", "需要排毒养颜的女性", "喜欢结合自然与养生的人士"],
      },
    ]

    // Filter and sort plans based on preferences
    // This is a simplified version - in a real app, this would be more sophisticated
    if (preferences.environment?.includes("mountain")) {
      // Prioritize mountain plans
      plans.sort((a, b) => {
        if (a.location === "莫干山" || a.location === "黄山") return -1
        if (b.location === "莫干山" || b.location === "黄山") return 1
        return 0
      })
    } else if (preferences.environment?.includes("seaside")) {
      // Prioritize seaside plans
      plans.sort((a, b) => {
        if (a.location === "三亚") return -1
        if (b.location === "三亚") return 1
        return 0
      })
    }

    return plans
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-primary">正在为您匹配康养旅行方案</CardTitle>
            <CardDescription>请稍候...</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-primary">为您推荐的康养旅行方案</CardTitle>
          <CardDescription>基于您的评估结果和偏好，我们精选了以下康养旅行方案</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Tabs defaultValue={travelPlans[0]?.id || "plan1"}>
            <TabsList className="grid grid-cols-3">
              {travelPlans.map((plan) => (
                <TabsTrigger key={plan.id} value={plan.id}>
                  {plan.location}
                </TabsTrigger>
              ))}
            </TabsList>

            {travelPlans.map((plan) => (
              <TabsContent key={plan.id} value={plan.id} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-bold">{plan.title}</h3>

                  <div className="flex flex-wrap gap-2 my-2">
                    {plan.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="bg-blue-50">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <p className="text-sm text-muted-foreground">{plan.description}</p>

                  <div className="grid grid-cols-2 gap-2 text-sm mt-4">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{plan.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{plan.duration}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>全年可约</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Wallet className="h-4 w-4 text-muted-foreground" />
                      <span>{plan.price}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">行程亮点</h4>
                  <ul className="text-sm space-y-1 list-disc list-inside">
                    {plan.highlights.map((highlight, index) => (
                      <li key={index}>{highlight}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">适合人群</h4>
                  <ul className="text-sm space-y-1 list-disc list-inside">
                    {plan.suitableFor.map((suitable, index) => (
                      <li key={index}>{suitable}</li>
                    ))}
                  </ul>
                </div>

                <Button className="w-full mt-4">查看详情并预约</Button>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.push("/assessment/results")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> 返回报告
          </Button>
          <Button variant="outline" onClick={() => router.push("/")}>
            完成测试
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

