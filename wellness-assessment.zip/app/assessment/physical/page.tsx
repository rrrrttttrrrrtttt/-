"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight } from "lucide-react"

export default function PhysicalAssessmentPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})

  const questions = [
    {
      id: "balance",
      question: "您能单脚站立不扶任何物体超过30秒吗？",
      options: [
        { value: "1", label: "完全不能" },
        { value: "2", label: "勉强能站几秒" },
        { value: "3", label: "能站10-20秒" },
        { value: "4", label: "能轻松站立30秒以上" },
      ],
    },
    {
      id: "stairs",
      question: "您爬楼梯时的感受是？",
      options: [
        { value: "1", label: "非常吃力，需要多次休息" },
        { value: "2", label: "有些吃力，偶尔需要休息" },
        { value: "3", label: "略有气喘，但能连续完成" },
        { value: "4", label: "轻松完成，没有明显不适" },
      ],
    },
    {
      id: "joints",
      question: "您的关节活动是否有不适？",
      options: [
        { value: "1", label: "经常疼痛，影响日常活动" },
        { value: "2", label: "偶尔疼痛，某些动作受限" },
        { value: "3", label: "很少不适，基本不影响活动" },
        { value: "4", label: "没有任何不适" },
      ],
    },
    {
      id: "sleep",
      question: "您的睡眠质量如何？",
      options: [
        { value: "1", label: "很差，经常失眠或早醒" },
        { value: "2", label: "一般，有时难以入睡" },
        { value: "3", label: "较好，偶尔会醒来" },
        { value: "4", label: "非常好，一觉到天亮" },
      ],
    },
    {
      id: "energy",
      question: "您的日常精力状态如何？",
      options: [
        { value: "1", label: "经常疲惫，需要休息" },
        { value: "2", label: "下午容易感到疲劳" },
        { value: "3", label: "精力充沛，偶尔疲劳" },
        { value: "4", label: "总是精力充沛" },
      ],
    },
  ]

  const currentQuestion = questions[currentStep]
  const progress = ((currentStep + 1) / questions.length) * 100

  const handleAnswer = (value: string) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }))
  }

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      // Save answers and proceed to next section
      localStorage.setItem("physicalAssessment", JSON.stringify(answers))
      router.push("/assessment/lifestyle")
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    } else {
      router.push("/assessment/basic-info")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex justify-between items-center mb-2">
            <CardTitle className="text-xl font-bold text-primary">身体机能评估</CardTitle>
            <span className="text-sm text-muted-foreground">
              {currentStep + 1}/{questions.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
          <CardDescription className="pt-2">请根据您的实际情况选择最符合的选项</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-lg font-medium">{currentQuestion.question}</div>

          <RadioGroup value={answers[currentQuestion.id] || ""} onValueChange={handleAnswer} className="space-y-3">
            {currentQuestion.options.map((option) => (
              <div
                key={option.value}
                className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-muted/50 transition-colors"
              >
                <RadioGroupItem value={option.value} id={`option-${option.value}`} />
                <Label htmlFor={`option-${option.value}`} className="flex-grow cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handlePrevious}>
            <ArrowLeft className="mr-2 h-4 w-4" /> 上一步
          </Button>
          <Button onClick={handleNext} disabled={!answers[currentQuestion.id]}>
            {currentStep < questions.length - 1 ? "下一题" : "下一部分"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

