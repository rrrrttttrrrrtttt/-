import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-primary">康养旅行需求自测</CardTitle>
          <CardDescription>通过10分钟的互动评估，了解您的康养状况和潜在需求</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg bg-blue-50 p-4 text-sm">
            <p className="font-medium text-blue-700 mb-2">本测试将评估以下方面：</p>
            <ul className="list-disc list-inside space-y-1 text-blue-600">
              <li>身体机能状况</li>
              <li>生活习惯评估</li>
              <li>心理健康状态</li>
              <li>用药依从性</li>
              <li>康养需求偏好</li>
            </ul>
          </div>
          <div className="text-center text-sm text-muted-foreground">
            <p>完成测试后，您将获得一份个性化康养指数报告</p>
          </div>
        </CardContent>
        <CardFooter>
          <Link href="/assessment/intro" className="w-full">
            <Button className="w-full" size="lg">
              开始测试
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

