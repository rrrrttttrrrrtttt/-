"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Calendar, MapPin, Clock, Wallet, Heart, Award } from "lucide-react"

type TravelPlan = {
  id: string
  title: string
  location: string
  duration: string
  price: string
  image: string
  tags: string[]
  description: string
  highlights: string[]
  suitableFor: string[]
}

export default function TravelPlansPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [travelPlans, setTravelPlans] = useState<TravelPlan[]>([])
  const [preferences, setPreferences] = useState<Record<string, string[]>>({})

  useEffect(() => {
    // In a real app, this would fetch from an API based on user's assessment
    setTimeout(() => {
      try {
        const preferencesData = JSON.parse(localStorage.getItem("preferencesAssessment") || "{}")
        setPreferences(preferencesData)

        // Generate travel plans based on preferences
        setTravelPlans(generateTravelPlans(preferencesData))
        setLoading(false)
      } catch (error) {
        console.error("Error loading travel plans:", error)
        setLoading(false)
      }
    }, 1000)
  }, [])

  const generateTravelPlans = (preferences: Record<string, string[]>): TravelPlan[] => {
    // This would typically come from a backend API
    // For demo purposes, we'll generate some plans based on preferences

    const plans: TravelPlan[] = [
      {
        id: "plan1",
        title: "山水禅心·养生之旅",
        location: "莫干山",
        duration: "3天2晚",
        price: "¥3,800起/人",
        image: "/placeholder.svg?height=300&width=500",
        tags: ["中医养生", "森林疗愈", "冥想放松"],
        description: "位于莫干山深处的禅修康养基地，结合传统中医理念和现代健康科学，为您提供身心全方位的调理体验。",
        highlights: ["中医体质辨识与个性化调理", "森林浴与自然疗愈", "禅修冥想课程", "有机食材健康餐饮"],
        suitableFor: ["压力较大需要放松的都市人群", "对中医养生感兴趣的人士", "需要改善睡眠质量的人群"],
      },
      {
        id: "plan2",
        title: "海滨康复·活力重塑",
        location: "三亚",
        duration: "5天4晚",
        price: "¥6,500起/人",
        image: "/placeholder.svg?height=300&width=500",
        tags: ["康复理疗", "水疗SPA", "营养调理"],
        description:
          "三亚五星级度假酒店内的专业康复中心，配备先进的康复设备和专业医疗团队，适合需要专业康复指导的人群。",
        highlights: ["专业康复评估与指导", "海洋水疗与理疗", "个性化营养餐饮计划", "海滨瑜伽与太极课程"],
        suitableFor: ["亚健康状态需要调理的人群", "术后康复期的人士", "需要专业健康指导的中老年人"],
      },
      {
        id: "plan3",
        title: "温泉养心·轻奢之旅",
        location: "黄山",
        duration: "4天3晚",
        price: "¥4,200起/人",
        image: "/placeholder.svg?height=300&width=500",
        tags: ["温泉疗养", "养生膳食", "户外徒步"],
        description: "黄山脚下的温泉度假村，结合当地丰富的温泉资源和养生文化，提供全方位的身心调养体验。",
        highlights: ["天然温泉浸泡疗法", "中医经络按摩", "养生膳食工作坊", "黄山轻度徒步"],
        suitableFor: ["关节不适需要改善的人群", "需要排毒养颜的女性", "喜欢结合自然与养生的人士"],
      },
    ]

    // Filter and sort plans based on preferences
    // This is a simplified version - in a real app, this would be more sophisticated
    if (preferences.environment?.includes("mountain")) {
      // Prioritize mountain plans
      plans.sort((a, b) => {
        if (a.location === "莫干山" || a.location === "黄山") return -1
        if (b.location === "莫干山" || b.location === "黄山") return 1
        return 0
      })
    } else if (preferences.environment?.includes("seaside")) {
      // Prioritize seaside plans
      plans.sort((a, b) => {
        if (a.location === "三亚") return -1
        if (b.location === "三亚") return 1
        return 0
      })
    }

    return plans
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-primary">正在为您匹配康养旅行方案</CardTitle>
            <CardDescription className="text-base">根据您的测试结果，为您精选最适合的康养旅行</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-6 py-10">
            <div className="relative w-32 h-32">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="匹配方案"
                fill
                className="object-contain animate-pulse"
              />
            </div>
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            <p className="text-sm text-muted-foreground animate-pulse">正在匹配最适合您的康养旅行...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
        <div className="relative w-full h-16 bg-gradient-to-r from-blue-400 to-green-400 flex items-center justify-center">
          <div className="absolute top-0 left-0 w-full h-full opacity-20">
            <Image src="/placeholder.svg?height=100&width=600" alt="背景" fill className="object-cover" />
          </div>
          <div className="relative z-10 flex items-center gap-2">
            <div className="bg-white rounded-full p-1.5">
              <Image
                src="/placeholder.svg?height=50&width=50"
                alt="旅行方案"
                width={24}
                height={24}
                className="rounded-full"
              />
            </div>
            <span className="text-white font-medium">为您推荐的康养旅行方案</span>
          </div>
        </div>

        <CardHeader>
          <CardTitle className="text-xl font-bold text-primary text-center">专属康养旅行推荐</CardTitle>
          <CardDescription className="text-center text-base">
            根据您的健康状况和偏好，我们精选了以下方案
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <Tabs defaultValue={travelPlans[0]?.id || "plan1"} className="w-full">
            <TabsList className="grid grid-cols-3 rounded-xl p-1">
              {travelPlans.map((plan) => (
                <TabsTrigger
                  key={plan.id}
                  value={plan.id}
                  className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white"
                >
                  {plan.location}
                </TabsTrigger>
              ))}
            </TabsList>

            {travelPlans.map((plan) => (
              <TabsContent key={plan.id} value={plan.id} className="space-y-4 pt-4">
                <div className="relative w-full h-48 rounded-2xl overflow-hidden">
                  <Image src={plan.image || "/placeholder.svg"} alt={plan.title} fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-4 text-white">
                    <h3 className="text-xl font-bold">{plan.title}</h3>
                    <div className="flex items-center gap-1 text-sm opacity-90">
                      <MapPin className="h-3.5 w-3.5" /> {plan.location}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 my-2">
                  {plan.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="bg-blue-50 rounded-lg">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <p className="text-sm text-muted-foreground">{plan.description}</p>

                <div className="grid grid-cols-2 gap-3 text-sm mt-4">
                  <div className="flex items-center gap-2 bg-blue-50 p-2.5 rounded-xl">
                    <Calendar className="h-4 w-4 text-blue-500" />
                    <span>{plan.duration}</span>
                  </div>
                  <div className="flex items-center gap-2 bg-green-50 p-2.5 rounded-xl">
                    <Clock className="h-4 w-4 text-green-500" />
                    <span>全年可约</span>
                  </div>
                  <div className="flex items-center gap-2 bg-purple-50 p-2.5 rounded-xl col-span-2">
                    <Wallet className="h-4 w-4 text-purple-500" />
                    <span className="font-medium">{plan.price}</span>
                  </div>
                </div>

                <div className="space-y-2 bg-blue-50 p-4 rounded-xl border border-blue-100">
                  <h4 className="font-medium flex items-center gap-2">
                    <span className="bg-blue-200 p-1 rounded-full">
                      <Heart className="h-4 w-4 text-blue-600" />
                    </span>
                    行程亮点
                  </h4>
                  <ul className="text-sm space-y-2">
                    {plan.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="inline-flex items-center justify-center bg-blue-200 text-blue-700 rounded-full w-5 h-5 text-xs font-medium flex-shrink-0 mt-0.5">
                          {index + 1}
                        </span>
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2 bg-green-50 p-4 rounded-xl border border-green-100">
                  <h4 className="font-medium flex items-center gap-2">
                    <span className="bg-green-200 p-1 rounded-full">
                      <Award className="h-4 w-4 text-green-600" />
                    </span>
                    适合人群
                  </h4>
                  <ul className="text-sm space-y-2">
                    {plan.suitableFor.map((suitable, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="inline-flex items-center justify-center bg-green-200 text-green-700 rounded-full w-5 h-5 text-xs font-medium flex-shrink-0 mt-0.5">
                          {index + 1}
                        </span>
                        <span>{suitable}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <Button className="w-full rounded-xl py-5 text-lg font-medium shadow-md hover:shadow-lg transition-all mt-4">
                  查看详情并预约
                </Button>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>

        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.push("/assessment/results")} className="rounded-xl">
            <ArrowLeft className="mr-2 h-4 w-4" /> 返回报告
          </Button>
          <Button variant="outline" onClick={() => router.push("/")} className="rounded-xl">
            完成测试
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

