"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight } from "lucide-react"

export default function LifestyleAssessmentPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})

  const questions = [
    {
      id: "exercise",
      question: "您每周进行有氧运动（如快走、游泳、骑车）的频率是？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "几乎不运动" },
        { value: "2", label: "每周1-2次" },
        { value: "3", label: "每周3-4次" },
        { value: "4", label: "每周5次以上" },
      ],
    },
    {
      id: "diet",
      question: "您的饮食结构如何？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "不规律，常吃快餐或加工食品" },
        { value: "2", label: "基本规律，但营养不均衡" },
        { value: "3", label: "规律且较为均衡" },
        { value: "4", label: "非常规律，营养均衡全面" },
      ],
    },
    {
      id: "water",
      question: "您每天的饮水量是？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "少于500ml" },
        { value: "2", label: "500-1000ml" },
        { value: "3", label: "1000-1500ml" },
        { value: "4", label: "1500ml以上" },
      ],
    },
    {
      id: "smoking",
      question: "您是否吸烟？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "每天吸烟" },
        { value: "2", label: "偶尔吸烟" },
        { value: "3", label: "已戒烟" },
        { value: "4", label: "从不吸烟" },
      ],
    },
    {
      id: "alcohol",
      question: "您的饮酒情况是？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "经常饮酒（每周多次）" },
        { value: "2", label: "适量饮酒（每周1-2次）" },
        { value: "3", label: "偶尔饮酒（社交场合）" },
        { value: "4", label: "几乎不饮酒" },
      ],
    },
  ]

  const currentQuestion = questions[currentStep]
  const progress = ((currentStep + 1) / questions.length) * 100

  const handleAnswer = (value: string) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }))
  }

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      // Save answers and proceed to next section
      localStorage.setItem("lifestyleAssessment", JSON.stringify(answers))
      router.push("/assessment/mental")
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    } else {
      router.push("/assessment/physical")
    }
  }

  // Encouraging messages based on progress
  const getEncouragingMessage = () => {
    const completedPercentage = (Object.keys(answers).length / questions.length) * 100

    if (completedPercentage < 20) return "探索您的生活习惯！"
    if (completedPercentage < 40) return "很棒！继续了解自己！"
    if (completedPercentage < 60) return "已经过半，您做得太好了！"
    if (completedPercentage < 80) return "即将完成这部分，加油！"
    return "太棒了，马上就完成了！"
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
        <div className="relative w-full h-16 bg-gradient-to-r from-blue-400 to-green-400 flex items-center justify-center">
          <div className="absolute top-0 left-0 w-full h-full opacity-20">
            <Image src="/placeholder.svg?height=100&width=600" alt="背景" fill className="object-cover" />
          </div>
          <div className="relative z-10 flex items-center gap-2">
            <div className="bg-white rounded-full p-1.5">
              <Image
                src="/placeholder.svg?height=50&width=50"
                alt="生活习惯"
                width={24}
                height={24}
                className="rounded-full"
              />
            </div>
            <span className="text-white font-medium">第三步：了解您的生活习惯</span>
          </div>
        </div>

        <CardHeader>
          <div className="flex flex-col items-center mb-2">
            <div className="w-full flex justify-between items-center mb-1">
              <span className="text-sm text-primary font-medium">
                已完成 {currentStep}/{questions.length}
              </span>
              <span className="text-sm text-primary font-medium">{Math.round(progress)}%</span>
            </div>
            <Progress
              value={progress}
              className="h-2.5 w-full rounded-full bg-blue-100"
              indicatorClassName="bg-gradient-to-r from-blue-400 to-green-400"
            />
            <CardDescription className="pt-3 text-center">{getEncouragingMessage()}</CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="text-lg font-medium text-center">{currentQuestion.question}</div>

          <div className="flex justify-center">
            <div className="relative w-32 h-32">
              <Image
                src={currentQuestion.image || "/placeholder.svg"}
                alt={currentQuestion.question}
                fill
                className="object-contain"
              />
            </div>
          </div>

          <RadioGroup value={answers[currentQuestion.id] || ""} onValueChange={handleAnswer} className="space-y-3">
            {currentQuestion.options.map((option) => (
              <div
                key={option.value}
                className={`flex items-center space-x-2 border-2 rounded-xl p-3.5 transition-all cursor-pointer ${
                  answers[currentQuestion.id] === option.value
                    ? "border-primary bg-primary/5 shadow-md"
                    : "border-gray-200 hover:border-primary/30 hover:bg-blue-50/50"
                }`}
                onClick={() => handleAnswer(option.value)}
              >
                <RadioGroupItem value={option.value} id={`option-${option.value}`} className="text-primary" />
                <Label htmlFor={`option-${option.value}`} className="flex-grow cursor-pointer font-medium">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>

        <CardFooter className="flex justify-between gap-3">
          <Button variant="outline" onClick={handlePrevious} className="rounded-xl px-5">
            <ArrowLeft className="mr-2 h-4 w-4" /> 上一题
          </Button>
          <Button onClick={handleNext} disabled={!answers[currentQuestion.id]} className="rounded-xl px-5 flex-1">
            {currentStep < questions.length - 1 ? "下一题" : "继续测试"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

