"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Download, Share2, Award, Heart, Brain, Pill, Sparkles } from "lucide-react"

type ScoreData = {
  physical: number
  lifestyle: number
  mental: number
  medication: number
  overall: number
}

export default function ResultsPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [scores, setScores] = useState<ScoreData>({
    physical: 0,
    lifestyle: 0,
    mental: 0,
    medication: 0,
    overall: 0,
  })
  const [recommendations, setRecommendations] = useState<string[]>([])
  const [preferences, setPreferences] = useState<Record<string, string[]>>({})

  useEffect(() => {
    // In a real app, this would be a server call to calculate scores
    // For demo purposes, we'll simulate loading and calculate locally
    setTimeout(() => {
      calculateScores()
      setLoading(false)
    }, 1500)
  }, [])

  const calculateScores = () => {
    try {
      // Get assessment data from localStorage
      const physicalData = JSON.parse(localStorage.getItem("physicalAssessment") || "{}")
      const lifestyleData = JSON.parse(localStorage.getItem("lifestyleAssessment") || "{}")
      const mentalData = JSON.parse(localStorage.getItem("mentalAssessment") || "{}")
      const medicationData = JSON.parse(localStorage.getItem("medicationAssessment") || "{}")
      const preferencesData = JSON.parse(localStorage.getItem("preferencesAssessment") || "{}")

      // Calculate scores (simplified for demo)
      const physicalScore = calculateSectionScore(physicalData)
      const lifestyleScore = calculateSectionScore(lifestyleData)
      const mentalScore = calculateSectionScore(mentalData)
      const medicationScore = calculateSectionScore(medicationData)

      // Calculate overall score
      const overall = Math.round((physicalScore + lifestyleScore + mentalScore + medicationScore) / 4)

      setScores({
        physical: physicalScore,
        lifestyle: lifestyleScore,
        mental: mentalScore,
        medication: medicationScore,
        overall,
      })

      setPreferences(preferencesData)

      // Generate recommendations based on scores
      setRecommendations(
        generateRecommendations(physicalScore, lifestyleScore, mentalScore, medicationScore, preferencesData),
      )
    } catch (error) {
      console.error("Error calculating scores:", error)
      // Handle error - in a real app, you might want to show an error message
    }
  }

  const calculateSectionScore = (data: Record<string, string>) => {
    // Simple calculation for demo purposes
    // In a real app, this would be more sophisticated
    const values = Object.values(data)
      .map((v) => Number.parseInt(v))
      .filter((v) => !isNaN(v))
    if (values.length === 0) return 0

    const sum = values.reduce((acc, val) => acc + val, 0)
    return Math.round((sum / (values.length * 4)) * 100) // Normalize to 0-100
  }

  const generateRecommendations = (
    physicalScore: number,
    lifestyleScore: number,
    mentalScore: number,
    medicationScore: number,
    preferences: Record<string, string[]>,
  ) => {
    const recommendations: string[] = []

    // Physical recommendations
    if (physicalScore < 50) {
      recommendations.push("建议进行专业的身体机能评估，并制定个性化的康复计划")
    } else if (physicalScore < 75) {
      recommendations.push("适当增加有氧运动和力量训练，提高身体机能")
    }

    // Lifestyle recommendations
    if (lifestyleScore < 50) {
      recommendations.push("建议调整生活习惯，增加运动频率，改善饮食结构")
    } else if (lifestyleScore < 75) {
      recommendations.push("保持良好的生活习惯，可适当增加户外活动时间")
    }

    // Mental recommendations
    if (mentalScore < 50) {
      recommendations.push("建议寻求专业心理咨询，学习压力管理技巧")
    } else if (mentalScore < 75) {
      recommendations.push("可尝试冥想、瑜伽等放松方式，提升心理健康水平")
    }

    // Medication recommendations
    if (medicationScore < 50) {
      recommendations.push("建议咨询医生，优化用药方案，提高用药依从性")
    } else if (medicationScore < 75) {
      recommendations.push("定期复查，保持良好的用药习惯")
    }

    // Add preference-based recommendations
    if (preferences.interests?.includes("tcm")) {
      recommendations.push("推荐参加中医养生主题的康养旅行，体验传统中医调理")
    }

    if (preferences.activities?.includes("yoga")) {
      recommendations.push("推荐参加包含瑜伽/太极课程的康养项目，帮助身心放松")
    }

    if (preferences.environment?.includes("mountain")) {
      recommendations.push("推荐前往山林环境的康养基地，享受负氧离子丰富的自然环境")
    }

    return recommendations
  }

  const getScoreColor = (score: number) => {
    if (score < 50) return "text-red-500"
    if (score < 75) return "text-yellow-500"
    return "text-green-500"
  }

  const getScoreText = (score: number) => {
    if (score < 50) return "需要改善"
    if (score < 75) return "良好"
    return "优秀"
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-primary">正在生成您的康养指数报告</CardTitle>
            <CardDescription className="text-base">请稍候，我们正在分析您的测试结果...</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-6 py-10">
            <div className="relative w-32 h-32">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="生成报告"
                fill
                className="object-contain animate-pulse"
              />
            </div>
            <Progress
              value={65}
              className="w-2/3 h-3 rounded-full bg-blue-100"
              indicatorClassName="bg-gradient-to-r from-blue-400 to-green-400"
            />
            <p className="text-sm text-muted-foreground animate-pulse">分析您的健康数据...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
        <div className="relative w-full h-40 bg-gradient-to-r from-blue-400 to-green-400">
          <div className="absolute top-0 left-0 w-full h-full opacity-20">
            <Image src="/placeholder.svg?height=300&width=600" alt="报告背景" fill className="object-cover" />
          </div>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
            <Sparkles className="h-10 w-10 mb-2" />
            <h2 className="text-2xl font-bold">康养指数报告</h2>
            <p className="text-sm opacity-90">基于您的测试结果生成</p>
          </div>
        </div>

        <CardHeader className="text-center">
          <div className="flex justify-center -mt-16">
            <div className="bg-white rounded-full p-3 shadow-lg border-4 border-white">
              <div className="relative w-24 h-24 bg-gradient-to-r from-blue-400 to-green-400 rounded-full flex items-center justify-center">
                <span className="text-4xl font-bold text-white">{scores.overall}</span>
              </div>
            </div>
          </div>
          <CardTitle className="text-xl font-bold text-primary mt-2">您的康养综合指数</CardTitle>
          <CardDescription className="text-base">恭喜您完成测试！以下是您的个性化康养建议</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <Tabs defaultValue="scores" className="w-full">
            <TabsList className="grid grid-cols-2 rounded-xl p-1">
              <TabsTrigger
                value="scores"
                className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white"
              >
                评估分数
              </TabsTrigger>
              <TabsTrigger
                value="recommendations"
                className="rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white"
              >
                康养建议
              </TabsTrigger>
            </TabsList>

            <TabsContent value="scores" className="space-y-4 pt-4">
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl border border-blue-100">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <Heart className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">身体机能</span>
                      <span className={`font-bold ${getScoreColor(scores.physical)}`}>{scores.physical}</span>
                    </div>
                    <Progress
                      value={scores.physical}
                      className="h-2 rounded-full bg-blue-100"
                      indicatorClassName="bg-gradient-to-r from-blue-400 to-green-400"
                    />
                    <div className="text-xs text-right mt-1 text-muted-foreground">{getScoreText(scores.physical)}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl border border-green-100">
                  <div className="bg-green-100 p-2 rounded-full">
                    <Award className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">生活习惯</span>
                      <span className={`font-bold ${getScoreColor(scores.lifestyle)}`}>{scores.lifestyle}</span>
                    </div>
                    <Progress
                      value={scores.lifestyle}
                      className="h-2 rounded-full bg-green-100"
                      indicatorClassName="bg-gradient-to-r from-green-400 to-teal-400"
                    />
                    <div className="text-xs text-right mt-1 text-muted-foreground">
                      {getScoreText(scores.lifestyle)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-xl border border-purple-100">
                  <div className="bg-purple-100 p-2 rounded-full">
                    <Brain className="h-5 w-5 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">心理健康</span>
                      <span className={`font-bold ${getScoreColor(scores.mental)}`}>{scores.mental}</span>
                    </div>
                    <Progress
                      value={scores.mental}
                      className="h-2 rounded-full bg-purple-100"
                      indicatorClassName="bg-gradient-to-r from-purple-400 to-pink-400"
                    />
                    <div className="text-xs text-right mt-1 text-muted-foreground">{getScoreText(scores.mental)}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-xl border border-orange-100">
                  <div className="bg-orange-100 p-2 rounded-full">
                    <Pill className="h-5 w-5 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">用药依从性</span>
                      <span className={`font-bold ${getScoreColor(scores.medication)}`}>{scores.medication}</span>
                    </div>
                    <Progress
                      value={scores.medication}
                      className="h-2 rounded-full bg-orange-100"
                      indicatorClassName="bg-gradient-to-r from-orange-400 to-red-400"
                    />
                    <div className="text-xs text-right mt-1 text-muted-foreground">
                      {getScoreText(scores.medication)}
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="recommendations" className="pt-4">
              <div className="space-y-3">
                {recommendations.map((recommendation, index) => (
                  <div key={index} className="p-4 bg-white rounded-xl text-sm border-2 border-primary/10 shadow-sm">
                    <div className="flex gap-3">
                      <div className="bg-primary/10 p-1.5 rounded-full h-6 w-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold text-primary">{index + 1}</span>
                      </div>
                      <p>{recommendation}</p>
                    </div>
                  </div>
                ))}

                <div className="flex justify-center mt-4">
                  <div className="relative w-32 h-32">
                    <Image src="/placeholder.svg?height=200&width=200" alt="康养建议" fill className="object-contain" />
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="flex flex-col gap-3">
          <div className="flex gap-2 w-full">
            <Button variant="outline" className="flex-1 rounded-xl">
              <Download className="mr-2 h-4 w-4" /> 保存报告
            </Button>
            <Button variant="outline" className="flex-1 rounded-xl">
              <Share2 className="mr-2 h-4 w-4" /> 分享
            </Button>
          </div>
          <Button
            variant="default"
            className="w-full rounded-xl py-5 text-lg font-medium shadow-md hover:shadow-lg transition-all"
            onClick={() => router.push("/assessment/travel-plans")}
          >
            查看适合您的康养旅行方案
          </Button>
          <Button variant="link" className="w-full" onClick={() => router.push("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> 返回首页
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

