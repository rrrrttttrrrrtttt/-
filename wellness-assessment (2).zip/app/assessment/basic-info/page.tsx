"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function BasicInfoPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    age: "",
    gender: "",
    height: "",
    weight: "",
    occupation: "",
  })

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = () => {
    // In a real app, you would validate and save this data
    localStorage.setItem("basicInfo", JSON.stringify(formData))
    router.push("/assessment/physical")
  }

  const isFormValid = () => {
    return formData.age && formData.gender && formData.height && formData.weight && formData.occupation
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
        <div className="relative w-full h-16 bg-gradient-to-r from-blue-400 to-green-400 flex items-center justify-center">
          <div className="absolute top-0 left-0 w-full h-full opacity-20">
            <Image src="/placeholder.svg?height=100&width=600" alt="背景" fill className="object-cover" />
          </div>
          <div className="relative z-10 flex items-center gap-2">
            <div className="bg-white rounded-full p-1.5">
              <Image
                src="/placeholder.svg?height=50&width=50"
                alt="基本信息"
                width={24}
                height={24}
                className="rounded-full"
              />
            </div>
            <span className="text-white font-medium">第一步：了解您的基本情况</span>
          </div>
        </div>

        <CardHeader>
          <CardTitle className="text-xl font-bold text-primary text-center">先来认识一下您</CardTitle>
          <CardDescription className="text-center text-base">这些基本信息将帮助我们提供更准确的评估</CardDescription>
        </CardHeader>

        <CardContent className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="age" className="text-sm font-medium">
                年龄
              </Label>
              <Input
                id="age"
                type="number"
                placeholder="请输入年龄"
                value={formData.age}
                onChange={(e) => handleChange("age", e.target.value)}
                className="rounded-xl border-primary/20 focus:border-primary focus:ring-primary"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium">性别</Label>
              <RadioGroup
                value={formData.gender}
                onValueChange={(value) => handleChange("gender", value)}
                className="flex space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="male" id="male" className="text-primary" />
                  <Label htmlFor="male">男</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="female" id="female" className="text-primary" />
                  <Label htmlFor="female">女</Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="height" className="text-sm font-medium">
                身高 (cm)
              </Label>
              <Input
                id="height"
                type="number"
                placeholder="请输入身高"
                value={formData.height}
                onChange={(e) => handleChange("height", e.target.value)}
                className="rounded-xl border-primary/20 focus:border-primary focus:ring-primary"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="weight" className="text-sm font-medium">
                体重 (kg)
              </Label>
              <Input
                id="weight"
                type="number"
                placeholder="请输入体重"
                value={formData.weight}
                onChange={(e) => handleChange("weight", e.target.value)}
                className="rounded-xl border-primary/20 focus:border-primary focus:ring-primary"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="occupation" className="text-sm font-medium">
              职业类型
            </Label>
            <Select value={formData.occupation} onValueChange={(value) => handleChange("occupation", value)}>
              <SelectTrigger
                id="occupation"
                className="rounded-xl border-primary/20 focus:border-primary focus:ring-primary"
              >
                <SelectValue placeholder="请选择职业类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="office">办公室工作</SelectItem>
                <SelectItem value="physical">体力劳动</SelectItem>
                <SelectItem value="freelance">自由职业</SelectItem>
                <SelectItem value="retired">退休人员</SelectItem>
                <SelectItem value="student">学生</SelectItem>
                <SelectItem value="other">其他</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-center mt-4">
            <div className="relative w-32 h-32">
              <Image src="/placeholder.svg?height=200&width=200" alt="填写信息" fill className="object-contain" />
            </div>
          </div>
        </CardContent>

        <CardFooter>
          <Button
            className="w-full rounded-xl py-6 text-lg font-medium shadow-md hover:shadow-lg transition-all"
            onClick={handleSubmit}
            disabled={!isFormValid()}
          >
            {isFormValid() ? "太棒了！继续下一步" : "请完成所有信息填写"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

