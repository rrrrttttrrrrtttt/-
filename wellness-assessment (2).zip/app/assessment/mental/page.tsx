"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight } from "lucide-react"

export default function MentalAssessmentPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})

  const questions = [
    {
      id: "stress",
      question: "您在过去一个月中感到压力大的频率是？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "几乎总是感到压力" },
        { value: "2", label: "经常感到压力" },
        { value: "3", label: "偶尔感到压力" },
        { value: "4", label: "很少或从不感到压力" },
      ],
    },
    {
      id: "mood",
      question: "您的情绪状态通常如何？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "经常感到焦虑或抑郁" },
        { value: "2", label: "情绪波动较大" },
        { value: "3", label: "情绪基本稳定" },
        { value: "4", label: "情绪积极乐观" },
      ],
    },
    {
      id: "concentration",
      question: "您的注意力集中程度如何？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "很难集中注意力" },
        { value: "2", label: "经常走神" },
        { value: "3", label: "偶尔分心" },
        { value: "4", label: "注意力集中良好" },
      ],
    },
    {
      id: "social",
      question: "您的社交活动频率如何？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "几乎不参与社交活动" },
        { value: "2", label: "很少参与社交活动" },
        { value: "3", label: "适度参与社交活动" },
        { value: "4", label: "经常参与社交活动" },
      ],
    },
    {
      id: "relaxation",
      question: "您是否有放松和减压的方法？",
      image: "/placeholder.svg?height=200&width=200",
      options: [
        { value: "1", label: "没有特定的放松方法" },
        { value: "2", label: "有时会尝试放松方法" },
        { value: "3", label: "有几种常用的放松方法" },
        { value: "4", label: "有系统的放松和减压习惯" },
      ],
    },
  ]

  const currentQuestion = questions[currentStep]
  const progress = ((currentStep + 1) / questions.length) * 100

  const handleAnswer = (value: string) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }))
  }

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      // Save answers and proceed to next section
      localStorage.setItem("mentalAssessment", JSON.stringify(answers))
      router.push("/assessment/medication")
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    } else {
      router.push("/assessment/lifestyle")
    }
  }

  // Encouraging messages based on progress
  const getEncouragingMessage = () => {
    const completedPercentage = (Object.keys(answers).length / questions.length) * 100

    if (completedPercentage < 20) return "开始了解您的心理健康！"
    if (completedPercentage < 40) return "很好！继续探索内心世界！"
    if (completedPercentage < 60) return "已经过半，您的坚持很棒！"
    if (completedPercentage < 80) return "即将完成心理评估，加油！"
    return "太棒了，您已经完成了大部分！"
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
        <div className="relative w-full h-16 bg-gradient-to-r from-blue-400 to-green-400 flex items-center justify-center">
          <div className="absolute top-0 left-0 w-full h-full opacity-20">
            <Image src="/placeholder.svg?height=100&width=600" alt="背景" fill className="object-cover" />
          </div>
          <div className="relative z-10 flex items-center gap-2">
            <div className="bg-white rounded-full p-1.5">
              <Image
                src="/placeholder.svg?height=50&width=50"
                alt="心理健康"
                width={24}
                height={24}
                className="rounded-full"
              />
            </div>
            <span className="text-white font-medium">第四步：了解您的心理健康</span>
          </div>
        </div>

        <CardHeader>
          <div className="flex flex-col items-center mb-2">
            <div className="w-full flex justify-between items-center mb-1">
              <span className="text-sm text-primary font-medium">
                已完成 {currentStep}/{questions.length}
              </span>
              <span className="text-sm text-primary font-medium">{Math.round(progress)}%</span>
            </div>
            <Progress
              value={progress}
              className="h-2.5 w-full rounded-full bg-blue-100"
              indicatorClassName="bg-gradient-to-r from-blue-400 to-green-400"
            />
            <CardDescription className="pt-3 text-center">{getEncouragingMessage()}</CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="text-lg font-medium text-center">{currentQuestion.question}</div>

          <div className="flex justify-center">
            <div className="relative w-32 h-32">
              <Image
                src={currentQuestion.image || "/placeholder.svg"}
                alt={currentQuestion.question}
                fill
                className="object-contain"
              />
            </div>
          </div>

          <RadioGroup value={answers[currentQuestion.id] || ""} onValueChange={handleAnswer} className="space-y-3">
            {currentQuestion.options.map((option) => (
              <div
                key={option.value}
                className={`flex items-center space-x-2 border-2 rounded-xl p-3.5 transition-all cursor-pointer ${
                  answers[currentQuestion.id] === option.value
                    ? "border-primary bg-primary/5 shadow-md"
                    : "border-gray-200 hover:border-primary/30 hover:bg-blue-50/50"
                }`}
                onClick={() => handleAnswer(option.value)}
              >
                <RadioGroupItem value={option.value} id={`option-${option.value}`} className="text-primary" />
                <Label htmlFor={`option-${option.value}`} className="flex-grow cursor-pointer font-medium">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>

        <CardFooter className="flex justify-between gap-3">
          <Button variant="outline" onClick={handlePrevious} className="rounded-xl px-5">
            <ArrowLeft className="mr-2 h-4 w-4" /> 上一题
          </Button>
          <Button onClick={handleNext} disabled={!answers[currentQuestion.id]} className="rounded-xl px-5 flex-1">
            {currentStep < questions.length - 1 ? "下一题" : "继续测试"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

