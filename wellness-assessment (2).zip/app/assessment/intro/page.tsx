"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

export default function IntroPage() {
  const router = useRouter()
  const [agreed, setAgreed] = useState(false)

  const handleStart = () => {
    if (agreed) {
      router.push("/assessment/basic-info")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
        <div className="relative w-full h-40">
          <Image src="/placeholder.svg?height=300&width=600" alt="测试说明" fill className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent"></div>
        </div>
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold text-primary">准备好了吗？</CardTitle>
          <CardDescription className="text-base">在开始前，让我们了解一下测试流程</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center">
            <div className="relative w-32 h-32">
              <Image src="/placeholder.svg?height=200&width=200" alt="准备开始" fill className="object-contain" />
            </div>
          </div>

          <div className="space-y-4 text-sm bg-blue-50 p-5 rounded-2xl border border-blue-100">
            <div className="flex items-start gap-3">
              <div className="bg-blue-200 text-blue-700 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                <span className="text-lg font-medium">1</span>
              </div>
              <p>
                本测试大约需要<span className="font-medium text-blue-700">10分钟</span>完成，请在安静环境中进行
              </p>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-blue-200 text-blue-700 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                <span className="text-lg font-medium">2</span>
              </div>
              <p>请根据您的真实情况回答，这样才能获得准确的评估结果</p>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-blue-200 text-blue-700 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                <span className="text-lg font-medium">3</span>
              </div>
              <p>测试结果仅供参考，不构成医疗诊断，您的数据将被安全保存</p>
            </div>
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <Checkbox
              id="terms"
              checked={agreed}
              onCheckedChange={(checked) => setAgreed(checked === true)}
              className="data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
            />
            <Label htmlFor="terms" className="text-sm">
              我已阅读并同意《用户协议》和《隐私政策》
            </Label>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            className="w-full rounded-xl py-6 text-lg font-medium shadow-md hover:shadow-lg transition-all"
            size="lg"
            onClick={handleStart}
            disabled={!agreed}
          >
            开始测试
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

