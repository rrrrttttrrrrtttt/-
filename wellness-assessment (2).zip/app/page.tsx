import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-primary/20 shadow-lg rounded-3xl overflow-hidden">
        <div className="relative w-full h-48">
          <Image src="/placeholder.svg?height=400&width=800" alt="康养旅行" fill className="object-cover" priority />
          <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent"></div>
        </div>
        <CardHeader className="text-center relative">
          <div className="absolute -top-16 left-1/2 -translate-x-1/2 bg-white rounded-full p-3 shadow-md border-4 border-primary/20">
            <Image
              src="/placeholder.svg?height=100&width=100"
              alt="Logo"
              width={60}
              height={60}
              className="rounded-full"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-primary mt-8">康养旅行需求自测</CardTitle>
          <CardDescription className="text-base">10分钟了解自己，开启专属康养之旅</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-2xl bg-blue-50 p-5 text-sm border border-blue-100">
            <p className="font-medium text-blue-700 mb-3">本测试将帮助您了解：</p>
            <ul className="space-y-2.5">
              {[
                "您的身体机能状况如何？",
                "您的生活习惯是否健康？",
                "您的心理健康状态怎样？",
                "您的用药习惯是否合理？",
                "哪种康养旅行最适合您？",
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-2 text-blue-600">
                  <span className="inline-flex items-center justify-center bg-blue-200 text-blue-700 rounded-full w-5 h-5 text-xs font-medium flex-shrink-0 mt-0.5">
                    {index + 1}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="text-center text-sm text-muted-foreground">
            <p>完成测试后，您将获得一份个性化康养指数报告 ✨</p>
          </div>
        </CardContent>
        <CardFooter>
          <Link href="/assessment/intro" className="w-full">
            <Button
              className="w-full rounded-xl py-6 text-lg font-medium shadow-md hover:shadow-lg transition-all"
              size="lg"
            >
              开始健康之旅
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}

