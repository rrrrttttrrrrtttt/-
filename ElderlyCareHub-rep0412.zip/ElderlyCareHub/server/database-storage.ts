import { 
  users, employees, residents, careServices, serviceRecords,
  type User, type InsertUser, type Employee, type InsertEmployee,
  type Resident, type InsertResident, type CareService, type InsertCareService,
  type ServiceRecord, type InsertServiceRecord, type EmployeeWithUser, type ServiceRecordDetails
} from "@shared/schema";
import { db, pool } from "./db";
import { eq, desc, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User Management Methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Employee Management Methods
  async getAllEmployeesWithUsers(): Promise<EmployeeWithUser[]> {
    const employeesList = await db.select().from(employees);
    const result: EmployeeWithUser[] = [];
    
    for (const employee of employeesList) {
      const user = await this.getUser(employee.userId!);
      if (user) {
        result.push({ ...employee, user });
      }
    }
    
    return result;
  }

  async getEmployeeWithUser(id: number): Promise<EmployeeWithUser | undefined> {
    const [employee] = await db
      .select()
      .from(employees)
      .where(eq(employees.id, id));
    
    if (!employee || !employee.userId) return undefined;
    
    const user = await this.getUser(employee.userId);
    if (!user) return undefined;
    
    return { ...employee, user };
  }

  async createEmployee(employeeData: InsertEmployee): Promise<EmployeeWithUser> {
    const [employee] = await db
      .insert(employees)
      .values(employeeData)
      .returning();
    
    const user = await this.getUser(employeeData.userId!);
    
    if (!user) {
      throw new Error("User not found");
    }
    
    return { ...employee, user };
  }

  async updateEmployee(id: number, employeeData: Partial<Employee>): Promise<EmployeeWithUser | undefined> {
    const [employee] = await db
      .update(employees)
      .set(employeeData)
      .where(eq(employees.id, id))
      .returning();
    
    if (!employee || !employee.userId) return undefined;
    
    const user = await this.getUser(employee.userId);
    if (!user) return undefined;
    
    return { ...employee, user };
  }

  async deleteEmployee(id: number): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  // Caregiver management (HR perspective)
  async getCaregivers(): Promise<EmployeeWithUser[]> {
    const caregiversList = await db
      .select()
      .from(employees)
      .where(eq(employees.isCaregiver, true));
    
    const caregivers: EmployeeWithUser[] = [];
    
    for (const caregiver of caregiversList) {
      const user = await this.getUser(caregiver.userId!);
      if (user) {
        // Add a syncedWithElderly field for demonstration
        caregivers.push({ 
          ...caregiver, 
          user,
          syncedWithElderly: Math.random() > 0.3 // Random sync status for demo
        });
      }
    }
    
    return caregivers;
  }

  async syncCaregiversWithElderlySystem(): Promise<void> {
    // Simulate a sync operation
    await new Promise(resolve => setTimeout(resolve, 1000));
    // In a real implementation, this would update the sync status in the database
  }

  // Caregiver management (Elderly Care perspective)
  async getCaregivesForElderlySystem(): Promise<EmployeeWithUser[]> {
    const caregivers = await this.getCaregivers();
    
    // Add additional fields relevant for the elderly care system
    return caregivers.map(caregiver => ({
      ...caregiver,
      syncedWithHR: Math.random() > 0.3, // Random sync status for demo
      onDuty: Math.random() > 0.5, // Random duty status for demo
      assignedResidentsCount: Math.floor(Math.random() * 5) // Random count for demo
    }));
  }

  async syncCaregiversWithHRSystem(): Promise<void> {
    // Simulate a sync operation
    await new Promise(resolve => setTimeout(resolve, 1000));
    // In a real implementation, this would update the sync status in the database
  }

  // HR Dashboard data
  async getRecentActivities(): Promise<any[]> {
    // In a real implementation, this would query a dedicated activities table
    return [
      {
        id: 1,
        type: "employee_added",
        description: "New caregiver Wang Lin added to the system",
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
        user: "Zhang Wei"
      },
      {
        id: 2,
        type: "sync_completed",
        description: "Caregiver data synchronized with Elderly Care system",
        timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        user: "System"
      },
      {
        id: 3,
        type: "employee_updated",
        description: "Updated position for Li Wei to Senior Caregiver",
        timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        user: "Zhang Wei"
      },
      {
        id: 4,
        type: "feedback_received",
        description: "Received performance feedback for Chen Hui",
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        user: "System"
      }
    ];
  }

  // Elderly Care Dashboard data
  async getElderlyDashboardData(): Promise<any> {
    const residents = await this.getAllResidents();
    const caregivers = await this.getCaregivesForElderlySystem();
    const serviceRecords = await this.getRecentServiceRecords();
    
    return {
      statistics: {
        totalResidents: residents.length,
        activeCaretakers: caregivers.filter(c => c.onDuty).length,
        completedServices: serviceRecords.filter(r => r.status === 'completed').length,
        upcomingServices: serviceRecords.filter(r => r.status === 'not_assigned' || r.status === 'in_progress').length
      },
      residentsByStatus: {
        independent: residents.filter(r => r.status === 'independent').length,
        partiallyDependent: residents.filter(r => r.status === 'partially_dependent').length,
        fullyDependent: residents.filter(r => r.status === 'fully_dependent').length
      },
      recentServiceRecords: serviceRecords.slice(0, 5),
      caregiverAvailability: caregivers.slice(0, 5).map(c => ({
        name: c.user.fullName,
        avatar: c.user.avatar,
        onDuty: c.onDuty,
        assignedResidents: c.assignedResidentsCount
      }))
    };
  }

  // Resident management
  async getAllResidents(): Promise<Resident[]> {
    return db.select().from(residents);
  }

  async getResident(id: number): Promise<Resident | undefined> {
    const [resident] = await db
      .select()
      .from(residents)
      .where(eq(residents.id, id));
    return resident;
  }

  async createResident(residentData: InsertResident): Promise<Resident> {
    const [resident] = await db
      .insert(residents)
      .values(residentData)
      .returning();
    return resident;
  }

  async updateResident(id: number, residentData: Partial<Resident>): Promise<Resident | undefined> {
    const [updatedResident] = await db
      .update(residents)
      .set(residentData)
      .where(eq(residents.id, id))
      .returning();
    return updatedResident;
  }

  // Care Service management
  async getAllCareServices(): Promise<CareService[]> {
    return db.select().from(careServices);
  }

  async getCareService(id: number): Promise<CareService | undefined> {
    const [service] = await db
      .select()
      .from(careServices)
      .where(eq(careServices.id, id));
    return service;
  }

  async createCareService(serviceData: InsertCareService): Promise<CareService> {
    const [service] = await db
      .insert(careServices)
      .values(serviceData)
      .returning();
    return service;
  }

  // Service Record management
  async getAllServiceRecords(): Promise<ServiceRecordDetails[]> {
    const records = await db
      .select()
      .from(serviceRecords);
    
    return this.enrichServiceRecords(records);
  }

  async getRecentServiceRecords(): Promise<ServiceRecordDetails[]> {
    const records = await db
      .select()
      .from(serviceRecords)
      .orderBy(desc(serviceRecords.scheduledTime))
      .limit(10);
    
    return this.enrichServiceRecords(records);
  }

  async getServiceRecord(id: number): Promise<ServiceRecordDetails | undefined> {
    const [record] = await db
      .select()
      .from(serviceRecords)
      .where(eq(serviceRecords.id, id));
    
    if (!record) return undefined;
    
    const recordsWithDetails = await this.enrichServiceRecords([record]);
    return recordsWithDetails[0];
  }

  async createServiceRecord(recordData: InsertServiceRecord): Promise<ServiceRecordDetails> {
    const [record] = await db
      .insert(serviceRecords)
      .values(recordData)
      .returning();
    
    const recordsWithDetails = await this.enrichServiceRecords([record]);
    return recordsWithDetails[0];
  }

  async updateServiceRecord(id: number, recordData: Partial<ServiceRecord>): Promise<ServiceRecordDetails | undefined> {
    const [updatedRecord] = await db
      .update(serviceRecords)
      .set(recordData)
      .where(eq(serviceRecords.id, id))
      .returning();
    
    if (!updatedRecord) return undefined;
    
    const recordsWithDetails = await this.enrichServiceRecords([updatedRecord]);
    return recordsWithDetails[0];
  }

  // Helper method to enrich service records with related data
  private async enrichServiceRecords(records: ServiceRecord[]): Promise<ServiceRecordDetails[]> {
    const result: ServiceRecordDetails[] = [];
    
    for (const record of records) {
      const resident = record.residentId 
        ? await this.getResident(record.residentId) 
        : undefined;
        
      const service = record.serviceId 
        ? await this.getCareService(record.serviceId) 
        : undefined;
        
      let employee: EmployeeWithUser | undefined;
      if (record.employeeId) {
        employee = await this.getEmployeeWithUser(record.employeeId);
      }
      
      if (resident && service) {
        result.push({
          ...record,
          resident,
          service,
          employee
        });
      }
    }
    
    return result;
  }
}