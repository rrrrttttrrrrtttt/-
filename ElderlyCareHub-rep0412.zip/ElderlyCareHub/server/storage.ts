import { 
  users, employees, residents, careServices, serviceRecords,
  type User, type InsertUser, type Employee, type InsertEmployee,
  type Resident, type InsertResident, type CareService, type InsertCareService,
  type ServiceRecord, type InsertServiceRecord, type EmployeeWithUser, type ServiceRecordDetails
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Extended types for the application
type ExtendedEmployeeWithUser = EmployeeWithUser & {
  syncedWithElderly?: boolean;
  syncedWithHR?: boolean;
  onDuty?: boolean;
  assignedResidentsCount?: number;
};

// Interface for the storage operations
export interface IStorage {
  // Session store
  sessionStore: session.Store;

  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;

  // Employee management
  getAllEmployeesWithUsers(): Promise<ExtendedEmployeeWithUser[]>;
  getEmployeeWithUser(id: number): Promise<ExtendedEmployeeWithUser | undefined>;
  createEmployee(employee: InsertEmployee): Promise<ExtendedEmployeeWithUser>;
  updateEmployee(id: number, employeeData: Partial<Employee>): Promise<ExtendedEmployeeWithUser | undefined>;
  deleteEmployee(id: number): Promise<void>;

  // Caregiver management (HR perspective)
  getCaregivers(): Promise<ExtendedEmployeeWithUser[]>;
  syncCaregiversWithElderlySystem(): Promise<void>;

  // Caregiver management (Elderly Care perspective)
  getCaregivesForElderlySystem(): Promise<ExtendedEmployeeWithUser[]>;
  syncCaregiversWithHRSystem(): Promise<void>;

  // HR Dashboard data
  getRecentActivities(): Promise<any[]>;

  // Elderly Care Dashboard data
  getElderlyDashboardData(): Promise<any>;

  // Resident management
  getAllResidents(): Promise<Resident[]>;
  getResident(id: number): Promise<Resident | undefined>;
  createResident(resident: InsertResident): Promise<Resident>;
  updateResident(id: number, residentData: Partial<Resident>): Promise<Resident | undefined>;

  // Care Service management
  getAllCareServices(): Promise<CareService[]>;
  getCareService(id: number): Promise<CareService | undefined>;
  createCareService(service: InsertCareService): Promise<CareService>;

  // Service Record management
  getAllServiceRecords(): Promise<ServiceRecordDetails[]>;
  getRecentServiceRecords(): Promise<ServiceRecordDetails[]>;
  getServiceRecord(id: number): Promise<ServiceRecordDetails | undefined>;
  createServiceRecord(record: InsertServiceRecord): Promise<ServiceRecordDetails>;
  updateServiceRecord(id: number, recordData: Partial<ServiceRecord>): Promise<ServiceRecordDetails | undefined>;
}

// In-memory implementation of the storage interface
export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private employeesMap: Map<number, Employee>;
  private residentsMap: Map<number, Resident>;
  private careServicesMap: Map<number, CareService>;
  private serviceRecordsMap: Map<number, ServiceRecord>;
  sessionStore: session.Store;
  
  private userIdCounter: number = 1;
  private employeeIdCounter: number = 1;
  private residentIdCounter: number = 1;
  private serviceIdCounter: number = 1;
  private recordIdCounter: number = 1;

  constructor() {
    this.usersMap = new Map();
    this.employeesMap = new Map();
    this.residentsMap = new Map();
    this.careServicesMap = new Map();
    this.serviceRecordsMap = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });

    // Initialize with sample data
    this.initializeSampleData();
  }

  // Initialize with some sample data for development
  private initializeSampleData() {
    // Create sample users for both roles
    const hrAdmin = this.createUserInternal({
      username: "hr_admin",
      password: "password123.abcdef", // pre-hashed password
      fullName: "Zhang Wei",
      email: "zhang.wei@enterprise.com",
      role: "hr_admin",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    const elderlyAdmin = this.createUserInternal({
      username: "elderly_admin",
      password: "password123.abcdef", // pre-hashed password
      fullName: "Li Mei",
      email: "li.mei@enterprise.com",
      role: "elderly_admin",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    // Sample care services
    this.createCareServiceInternal({
      name: "Medication Administration",
      description: "Daily medication administration and monitoring",
      frequency: "Daily • Morning",
      defaultDuration: 15
    });

    this.createCareServiceInternal({
      name: "Mobility Assistance",
      description: "Assistance with mobility and transfer",
      frequency: "Daily • Evening",
      defaultDuration: 30
    });

    this.createCareServiceInternal({
      name: "Social Activity",
      description: "Group social activities for mental stimulation",
      frequency: "Weekly • Afternoon",
      defaultDuration: 60
    });

    this.createCareServiceInternal({
      name: "Meal Assistance",
      description: "Help with meals and nutrition monitoring",
      frequency: "Daily • Meals",
      defaultDuration: 45
    });

    // Create sample employees and caregivers
    const caregiver1 = this.createUserInternal({
      username: "zhang_xiu",
      password: "password123.abcdef", 
      fullName: "Zhang Xiu",
      email: "zhangxiu@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    const caregiver2 = this.createUserInternal({
      username: "li_wei",
      password: "password123.abcdef", 
      fullName: "Li Wei",
      email: "liwei@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    const caregiver3 = this.createUserInternal({
      username: "chen_hui",
      password: "password123.abcdef", 
      fullName: "Chen Hui",
      email: "chenhui@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    const caregiver4 = this.createUserInternal({
      username: "wang_jie",
      password: "password123.abcdef", 
      fullName: "Wang Jie",
      email: "wangjie@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    // Create employee records for caregivers
    this.createEmployeeInternal({
      userId: caregiver1.id,
      position: "Senior Caregiver",
      department: "Care Services",
      employmentType: "full_time",
      joinDate: new Date("2021-09-15"),
      isCaregiver: true
    });

    this.createEmployeeInternal({
      userId: caregiver2.id,
      position: "Caregiver",
      department: "Care Services",
      employmentType: "full_time",
      joinDate: new Date("2022-01-05"),
      isCaregiver: true
    });

    this.createEmployeeInternal({
      userId: caregiver3.id,
      position: "Caregiver",
      department: "Care Services",
      employmentType: "part_time",
      joinDate: new Date("2022-04-12"),
      isCaregiver: true
    });

    this.createEmployeeInternal({
      userId: caregiver4.id,
      position: "Care Coordinator",
      department: "Management",
      employmentType: "full_time",
      joinDate: new Date("2020-11-30"),
      isCaregiver: true
    });

    // Create sample residents
    const resident1 = this.createResidentInternal({
      fullName: "Liu Mei Ling",
      roomNumber: "103",
      age: 78,
      status: "partially_dependent",
      careLevel: "Medium Care",
      avatar: "https://images.unsplash.com/photo-1551727974-8af20a3322f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    const resident2 = this.createResidentInternal({
      fullName: "Wang Jianyu",
      roomNumber: "215",
      age: 82,
      status: "fully_dependent",
      careLevel: "High Care",
      avatar: "https://images.unsplash.com/photo-1566616213894-2d4e1baee5d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    const resident3 = this.createResidentInternal({
      fullName: "Chen Bao",
      roomNumber: "142",
      age: 68,
      status: "independent",
      careLevel: "Basic Care",
      avatar: "https://images.unsplash.com/photo-1532635241-17e820acc59f?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    const resident4 = this.createResidentInternal({
      fullName: "Li Fei",
      roomNumber: "178",
      age: 90,
      status: "fully_dependent",
      careLevel: "High Care",
      avatar: "https://images.unsplash.com/photo-1497551060073-4c5ab6435f12?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    });

    // Create some service records
    this.createServiceRecordInternal({
      residentId: resident1.id,
      serviceId: 1, // Medication Administration
      employeeId: 1, // Zhang Xiu
      status: "completed",
      scheduledTime: new Date("2023-06-20T08:15:00"),
      completedTime: new Date("2023-06-20T08:30:00"),
      notes: "All medications administered successfully",
      feedback: "Resident was cooperative",
      rating: 5
    });

    this.createServiceRecordInternal({
      residentId: resident2.id,
      serviceId: 2, // Mobility Assistance
      employeeId: 2, // Li Wei
      status: "completed",
      scheduledTime: new Date("2023-06-19T18:30:00"),
      completedTime: new Date("2023-06-19T19:00:00"),
      notes: "Assisted with evening walk",
      feedback: "Resident needed extra support",
      rating: 4
    });

    this.createServiceRecordInternal({
      residentId: resident3.id,
      serviceId: 3, // Social Activity
      employeeId: 3, // Chen Hui
      status: "in_progress",
      scheduledTime: new Date("2023-06-25T14:00:00"),
      completedTime: null,
      notes: "Group art therapy session scheduled",
      feedback: null,
      rating: null
    });

    this.createServiceRecordInternal({
      residentId: resident4.id,
      serviceId: 4, // Meal Assistance
      employeeId: null, // Not assigned
      status: "not_assigned",
      scheduledTime: new Date("2023-06-23T18:00:00"),
      completedTime: null,
      notes: "Requires assistance with dinner",
      feedback: null,
      rating: null
    });
  }

  // Helper method to create a user internally
  private createUserInternal(userData: InsertUser): User {
    const id = this.userIdCounter++;
    const user: User = { ...userData, id };
    this.usersMap.set(id, user);
    return user;
  }

  // Helper method to create an employee internally
  private createEmployeeInternal(employeeData: InsertEmployee): Employee {
    const id = this.employeeIdCounter++;
    const employee: Employee = { ...employeeData, id };
    this.employeesMap.set(id, employee);
    return employee;
  }

  // Helper method to create a resident internally
  private createResidentInternal(residentData: InsertResident): Resident {
    const id = this.residentIdCounter++;
    const resident: Resident = { ...residentData, id };
    this.residentsMap.set(id, resident);
    return resident;
  }

  // Helper method to create a care service internally
  private createCareServiceInternal(serviceData: InsertCareService): CareService {
    const id = this.serviceIdCounter++;
    const service: CareService = { ...serviceData, id };
    this.careServicesMap.set(id, service);
    return service;
  }

  // Helper method to create a service record internally
  private createServiceRecordInternal(recordData: InsertServiceRecord): ServiceRecord {
    const id = this.recordIdCounter++;
    const record: ServiceRecord = { ...recordData, id };
    this.serviceRecordsMap.set(id, record);
    return record;
  }

  // User Management Methods
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.usersMap.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    return this.createUserInternal(userData);
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.usersMap.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.usersMap.set(id, updatedUser);
    return updatedUser;
  }

  // Employee Management Methods
  async getAllEmployeesWithUsers(): Promise<EmployeeWithUser[]> {
    const result: EmployeeWithUser[] = [];
    
    for (const employee of this.employeesMap.values()) {
      const user = this.usersMap.get(employee.userId!);
      if (user) {
        result.push({ ...employee, user });
      }
    }
    
    return result;
  }

  async getEmployeeWithUser(id: number): Promise<EmployeeWithUser | undefined> {
    const employee = this.employeesMap.get(id);
    if (!employee || !employee.userId) return undefined;
    
    const user = this.usersMap.get(employee.userId);
    if (!user) return undefined;
    
    return { ...employee, user };
  }

  async createEmployee(employeeData: InsertEmployee): Promise<EmployeeWithUser> {
    const employee = this.createEmployeeInternal(employeeData);
    const user = this.usersMap.get(employeeData.userId!);
    
    if (!user) {
      throw new Error("User not found");
    }
    
    return { ...employee, user };
  }

  async updateEmployee(id: number, employeeData: Partial<Employee>): Promise<EmployeeWithUser | undefined> {
    const employee = this.employeesMap.get(id);
    if (!employee || !employee.userId) return undefined;
    
    const updatedEmployee = { ...employee, ...employeeData };
    this.employeesMap.set(id, updatedEmployee);
    
    const user = this.usersMap.get(employee.userId);
    if (!user) return undefined;
    
    return { ...updatedEmployee, user };
  }

  async deleteEmployee(id: number): Promise<void> {
    this.employeesMap.delete(id);
  }

  // Caregiver management (HR perspective)
  async getCaregivers(): Promise<EmployeeWithUser[]> {
    const caregivers: EmployeeWithUser[] = [];
    
    for (const employee of this.employeesMap.values()) {
      if (employee.isCaregiver) {
        const user = this.usersMap.get(employee.userId!);
        if (user) {
          // Add a syncedWithElderly field for demonstration
          caregivers.push({ 
            ...employee, 
            user,
            syncedWithElderly: Math.random() > 0.3 // Random sync status for demo
          });
        }
      }
    }
    
    return caregivers;
  }

  async syncCaregiversWithElderlySystem(): Promise<void> {
    // Simulate a sync operation
    await new Promise(resolve => setTimeout(resolve, 1000));
    // In a real implementation, this would update the sync status in the database
  }

  // Caregiver management (Elderly Care perspective)
  async getCaregivesForElderlySystem(): Promise<EmployeeWithUser[]> {
    const caregivers = await this.getCaregivers();
    
    // Add additional fields relevant for the elderly care system
    return caregivers.map(caregiver => ({
      ...caregiver,
      syncedWithHR: Math.random() > 0.3, // Random sync status for demo
      onDuty: Math.random() > 0.5, // Random duty status for demo
      assignedResidentsCount: Math.floor(Math.random() * 5) // Random count for demo
    }));
  }

  async syncCaregiversWithHRSystem(): Promise<void> {
    // Simulate a sync operation
    await new Promise(resolve => setTimeout(resolve, 1000));
    // In a real implementation, this would update the sync status in the database
  }

  // HR Dashboard data
  async getRecentActivities(): Promise<any[]> {
    // Return sample activities
    return [
      {
        id: 1,
        type: "training",
        user: {
          fullName: "Liu Mei",
          avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
        },
        description: "completed training on Elderly Care Basics",
        timestamp: new Date("2023-06-20T10:34:00")
      },
      {
        id: 2,
        type: "review",
        user: {
          fullName: "Wang Jie",
          avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
        },
        description: "submitted performance review for Chen Hui",
        timestamp: new Date("2023-06-19T15:22:00")
      },
      {
        id: 3,
        type: "application",
        description: "received for Senior Caregiver position",
        timestamp: new Date("2023-06-19T11:05:00")
      },
      {
        id: 4,
        type: "schedule",
        description: "for next week has been approved",
        timestamp: new Date("2023-06-18T09:15:00")
      }
    ];
  }

  // Elderly Care Dashboard data
  async getElderlyDashboardData(): Promise<any> {
    // Count residents
    const totalResidents = this.residentsMap.size;
    
    // Count active services
    const careServices = this.careServicesMap.size;
    
    // Count caregivers on duty
    const caregiversOnDuty = Math.floor(this.employeesMap.size * 0.6); // 60% of caregivers on duty for demo
    
    // Count pending requests
    const pendingRequests = Array.from(this.serviceRecordsMap.values())
      .filter(record => record.status === "not_assigned")
      .length;
    
    return {
      totalResidents,
      activeServices: careServices,
      caregiversOnDuty,
      pendingRequests
    };
  }

  // Resident Management Methods
  async getAllResidents(): Promise<Resident[]> {
    return Array.from(this.residentsMap.values());
  }

  async getResident(id: number): Promise<Resident | undefined> {
    return this.residentsMap.get(id);
  }

  async createResident(residentData: InsertResident): Promise<Resident> {
    return this.createResidentInternal(residentData);
  }

  async updateResident(id: number, residentData: Partial<Resident>): Promise<Resident | undefined> {
    const resident = this.residentsMap.get(id);
    if (!resident) return undefined;
    
    const updatedResident = { ...resident, ...residentData };
    this.residentsMap.set(id, updatedResident);
    return updatedResident;
  }

  // Care Service Management Methods
  async getAllCareServices(): Promise<CareService[]> {
    return Array.from(this.careServicesMap.values());
  }

  async getCareService(id: number): Promise<CareService | undefined> {
    return this.careServicesMap.get(id);
  }

  async createCareService(serviceData: InsertCareService): Promise<CareService> {
    return this.createCareServiceInternal(serviceData);
  }

  // Service Record Management Methods
  async getAllServiceRecords(): Promise<ServiceRecordDetails[]> {
    const records: ServiceRecordDetails[] = [];
    
    for (const record of this.serviceRecordsMap.values()) {
      const resident = this.residentsMap.get(record.residentId);
      const service = this.careServicesMap.get(record.serviceId);
      
      if (!resident || !service) continue;
      
      let employee: EmployeeWithUser | undefined = undefined;
      
      if (record.employeeId) {
        const emp = this.employeesMap.get(record.employeeId);
        if (emp && emp.userId) {
          const user = this.usersMap.get(emp.userId);
          if (user) {
            employee = { ...emp, user };
          }
        }
      }
      
      records.push({
        ...record,
        resident,
        service,
        employee
      });
    }
    
    return records;
  }

  async getRecentServiceRecords(): Promise<ServiceRecordDetails[]> {
    const allRecords = await this.getAllServiceRecords();
    
    // Sort by scheduledTime (most recent first) and take top 10
    return allRecords
      .sort((a, b) => new Date(b.scheduledTime).getTime() - new Date(a.scheduledTime).getTime())
      .slice(0, 10);
  }

  async getServiceRecord(id: number): Promise<ServiceRecordDetails | undefined> {
    const record = this.serviceRecordsMap.get(id);
    if (!record) return undefined;
    
    const resident = this.residentsMap.get(record.residentId);
    const service = this.careServicesMap.get(record.serviceId);
    
    if (!resident || !service) return undefined;
    
    let employee: EmployeeWithUser | undefined = undefined;
    
    if (record.employeeId) {
      const emp = this.employeesMap.get(record.employeeId);
      if (emp && emp.userId) {
        const user = this.usersMap.get(emp.userId);
        if (user) {
          employee = { ...emp, user };
        }
      }
    }
    
    return {
      ...record,
      resident,
      service,
      employee
    };
  }

  async createServiceRecord(recordData: InsertServiceRecord): Promise<ServiceRecordDetails> {
    const record = this.createServiceRecordInternal(recordData);
    
    const resident = this.residentsMap.get(record.residentId);
    const service = this.careServicesMap.get(record.serviceId);
    
    if (!resident || !service) {
      throw new Error("Resident or service not found");
    }
    
    let employee: EmployeeWithUser | undefined = undefined;
    
    if (record.employeeId) {
      const emp = this.employeesMap.get(record.employeeId);
      if (emp && emp.userId) {
        const user = this.usersMap.get(emp.userId);
        if (user) {
          employee = { ...emp, user };
        }
      }
    }
    
    return {
      ...record,
      resident,
      service,
      employee
    };
  }

  async updateServiceRecord(id: number, recordData: Partial<ServiceRecord>): Promise<ServiceRecordDetails | undefined> {
    const record = this.serviceRecordsMap.get(id);
    if (!record) return undefined;
    
    const updatedRecord = { ...record, ...recordData };
    this.serviceRecordsMap.set(id, updatedRecord);
    
    const resident = this.residentsMap.get(updatedRecord.residentId);
    const service = this.careServicesMap.get(updatedRecord.serviceId);
    
    if (!resident || !service) return undefined;
    
    let employee: EmployeeWithUser | undefined = undefined;
    
    if (updatedRecord.employeeId) {
      const emp = this.employeesMap.get(updatedRecord.employeeId);
      if (emp && emp.userId) {
        const user = this.usersMap.get(emp.userId);
        if (user) {
          employee = { ...emp, user };
        }
      }
    }
    
    return {
      ...updatedRecord,
      resident,
      service,
      employee
    };
  }
}

// Create and export a singleton instance of the storage
// Import the new DatabaseStorage class
import { DatabaseStorage } from "./database-storage";

// Use DatabaseStorage when we have a DATABASE_URL
export const storage = process.env.DATABASE_URL ? new DatabaseStorage() : new MemStorage();
