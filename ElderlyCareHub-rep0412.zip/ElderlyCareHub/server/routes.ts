import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { roleGuard } from "./middleware/role-guard";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes and middleware
  setupAuth(app);

  // API Routes
  // ==== Auth and User Management ====
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Remove password from the returned user object
    const { password, ...userWithoutPassword } = req.user;
    res.status(200).json(userWithoutPassword);
  });

  // ==== HR Management Routes ====
  // Get all employees
  app.get("/api/employees", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      const employees = await storage.getAllEmployeesWithUsers();
      res.json(employees);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get employee by ID
  app.get("/api/employees/:id", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployeeWithUser(id);
      
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      
      res.json(employee);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create employee
  app.post("/api/employees", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      const employee = await storage.createEmployee(req.body);
      res.status(201).json(employee);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Update employee
  app.put("/api/employees/:id", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.updateEmployee(id, req.body);
      
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      
      res.json(employee);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Delete employee
  app.delete("/api/employees/:id", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteEmployee(id);
      res.status(204).end();
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // HR Caregivers management
  app.get("/api/hr/caregivers", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      const caregivers = await storage.getCaregivers();
      res.json(caregivers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Sync HR caregivers with Elderly Care system
  app.post("/api/hr/caregivers/sync-with-elderly", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      await storage.syncCaregiversWithElderlySystem();
      res.json({ message: "Caregivers successfully synchronized with Elderly Care system" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Recent activity for HR dashboard
  app.get("/api/recent-activity", roleGuard(["hr_admin"]), async (req, res) => {
    try {
      const activities = await storage.getRecentActivities();
      res.json(activities);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // ==== Elderly Care Management Routes ====
  // Dashboard data
  app.get("/api/elderly/dashboard", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const dashboardData = await storage.getElderlyDashboardData();
      res.json(dashboardData);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Residents
  app.get("/api/elderly/residents", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const residents = await storage.getAllResidents();
      res.json(residents);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/elderly/residents/:id", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const resident = await storage.getResident(id);
      
      if (!resident) {
        return res.status(404).json({ message: "Resident not found" });
      }
      
      res.json(resident);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/elderly/residents", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const resident = await storage.createResident(req.body);
      res.status(201).json(resident);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Elderly Care System caregivers
  app.get("/api/elderly/caregivers", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const caregivers = await storage.getCaregivesForElderlySystem();
      res.json(caregivers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Sync Elderly Care caregivers with HR system
  app.post("/api/elderly/caregivers/sync-with-hr", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      await storage.syncCaregiversWithHRSystem();
      res.json({ message: "Caregivers successfully synchronized with HR system" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Care Services
  app.get("/api/elderly/services", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const services = await storage.getAllCareServices();
      res.json(services);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/elderly/services", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const service = await storage.createCareService(req.body);
      res.status(201).json(service);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Service Records
  app.get("/api/elderly/service-records", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const records = await storage.getAllServiceRecords();
      res.json(records);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/elderly/service-records/recent", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const records = await storage.getRecentServiceRecords();
      res.json(records);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/elderly/service-records", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const record = await storage.createServiceRecord(req.body);
      res.status(201).json(record);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/elderly/service-records/:id", roleGuard(["elderly_admin"]), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const record = await storage.updateServiceRecord(id, req.body);
      
      if (!record) {
        return res.status(404).json({ message: "Service record not found" });
      }
      
      res.json(record);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
