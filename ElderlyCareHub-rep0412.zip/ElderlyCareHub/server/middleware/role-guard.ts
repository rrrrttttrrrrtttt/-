import { Request, Response, NextFunction } from 'express';

/**
 * Middleware to check if the user has the required role(s)
 * @param allowedRoles Array of roles that are allowed to access the route
 */
export const roleGuard = (allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    // Check if user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    // Check if user has one of the allowed roles
    const userRole = req.user?.role;
    
    if (!userRole || !allowedRoles.includes(userRole)) {
      return res.status(403).json({ 
        message: 'You do not have permission to access this resource',
        requiredRoles: allowedRoles,
        userRole
      });
    }

    // User has appropriate role, proceed
    next();
  };
};
