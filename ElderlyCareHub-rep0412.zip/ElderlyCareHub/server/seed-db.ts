import { db } from './db';
import { users, employees, residents, careServices, serviceRecords, userRoleEnum } from '@shared/schema';
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seedDatabase() {
  console.log('Seeding database...');
  
  // First check if we already have users
  const existingUsers = await db.select().from(users);
  if (existingUsers.length > 0) {
    console.log('Database already has data, skipping seeding.');
    return;
  }

  try {
    // Create admin users
    const hrAdmin = await db.insert(users).values({
      username: "hr_admin",
      password: "password123.abcdef", // Using our special password format that bypasses hashing
      fullName: "Zhang Wei",
      email: "zhang.wei@enterprise.com",
      role: "hr_admin",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    const elderlyAdmin = await db.insert(users).values({
      username: "elderly_admin",
      password: "password123.abcdef", // Using our special password format that bypasses hashing
      fullName: "Li Mei",
      email: "li.mei@enterprise.com",
      role: "elderly_admin",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    // Create caregiver users
    const caregiver1 = await db.insert(users).values({
      username: "zhang_xiu",
      password: "password123.abcdef",
      fullName: "Zhang Xiu",
      email: "zhangxiu@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    const caregiver2 = await db.insert(users).values({
      username: "li_wei",
      password: "password123.abcdef",
      fullName: "Li Wei",
      email: "liwei@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    const caregiver3 = await db.insert(users).values({
      username: "chen_hui",
      password: "password123.abcdef",
      fullName: "Chen Hui",
      email: "chenhui@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    const caregiver4 = await db.insert(users).values({
      username: "wang_jie",
      password: "password123.abcdef",
      fullName: "Wang Jie",
      email: "wangjie@example.com",
      role: "caregiver",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    // Create employee records for caregivers
    await db.insert(employees).values({
      userId: caregiver1[0].id,
      position: "Senior Caregiver",
      department: "Care Services",
      employmentType: "full_time",
      joinDate: new Date("2021-09-15"),
      isCaregiver: true
    });

    await db.insert(employees).values({
      userId: caregiver2[0].id,
      position: "Caregiver",
      department: "Care Services",
      employmentType: "full_time",
      joinDate: new Date("2022-01-05"),
      isCaregiver: true
    });

    await db.insert(employees).values({
      userId: caregiver3[0].id,
      position: "Caregiver",
      department: "Care Services",
      employmentType: "part_time",
      joinDate: new Date("2022-04-12"),
      isCaregiver: true
    });

    await db.insert(employees).values({
      userId: caregiver4[0].id,
      position: "Care Coordinator",
      department: "Management",
      employmentType: "full_time",
      joinDate: new Date("2020-11-30"),
      isCaregiver: true
    });

    // Create sample residents
    const resident1 = await db.insert(residents).values({
      fullName: "Liu Mei Ling",
      roomNumber: "103",
      age: 78,
      status: "partially_dependent",
      careLevel: "Medium Care",
      avatar: "https://images.unsplash.com/photo-1551727974-8af20a3322f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    const resident2 = await db.insert(residents).values({
      fullName: "Wang Jianyu",
      roomNumber: "215",
      age: 82,
      status: "fully_dependent",
      careLevel: "High Care",
      avatar: "https://images.unsplash.com/photo-1566616213894-2d4e1baee5d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    const resident3 = await db.insert(residents).values({
      fullName: "Chen Bao",
      roomNumber: "142",
      age: 68,
      status: "independent",
      careLevel: "Basic Care",
      avatar: "https://images.unsplash.com/photo-1532635241-17e820acc59f?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    const resident4 = await db.insert(residents).values({
      fullName: "Li Fei",
      roomNumber: "178",
      age: 90,
      status: "fully_dependent",
      careLevel: "High Care",
      avatar: "https://images.unsplash.com/photo-1497551060073-4c5ab6435f12?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }).returning();

    // Create sample care services
    const service1 = await db.insert(careServices).values({
      name: "Medication Administration",
      description: "Daily medication administration and monitoring",
      frequency: "Daily • Morning",
      defaultDuration: 15
    }).returning();

    const service2 = await db.insert(careServices).values({
      name: "Mobility Assistance",
      description: "Assistance with mobility and transfer",
      frequency: "Daily • Evening",
      defaultDuration: 30
    }).returning();

    const service3 = await db.insert(careServices).values({
      name: "Social Activity",
      description: "Group social activities for mental stimulation",
      frequency: "Weekly • Afternoon",
      defaultDuration: 60
    }).returning();

    const service4 = await db.insert(careServices).values({
      name: "Meal Assistance",
      description: "Help with meals and nutrition monitoring",
      frequency: "Daily • Meals",
      defaultDuration: 45
    }).returning();

    // Create service records
    const employeeData = await db.select().from(employees);

    await db.insert(serviceRecords).values({
      residentId: resident1[0].id,
      serviceId: service1[0].id,
      employeeId: employeeData[0].id,
      status: "completed",
      scheduledTime: new Date("2023-06-20T08:15:00"),
      completedTime: new Date("2023-06-20T08:30:00"),
      notes: "All medications administered successfully",
      feedback: "Resident was cooperative",
      rating: 5
    });

    await db.insert(serviceRecords).values({
      residentId: resident2[0].id,
      serviceId: service2[0].id,
      employeeId: employeeData[1].id,
      status: "completed",
      scheduledTime: new Date("2023-06-19T18:30:00"),
      completedTime: new Date("2023-06-19T19:00:00"),
      notes: "Assisted with evening walk",
      feedback: "Resident needed extra support",
      rating: 4
    });

    await db.insert(serviceRecords).values({
      residentId: resident3[0].id,
      serviceId: service3[0].id,
      employeeId: employeeData[2].id,
      status: "in_progress",
      scheduledTime: new Date("2023-06-25T14:00:00"),
      completedTime: null,
      notes: "Group art therapy session scheduled",
      feedback: null,
      rating: null
    });

    await db.insert(serviceRecords).values({
      residentId: resident4[0].id,
      serviceId: service4[0].id,
      employeeId: null,
      status: "not_assigned",
      scheduledTime: new Date("2023-06-23T18:00:00"),
      completedTime: null,
      notes: "Requires assistance with dinner",
      feedback: null,
      rating: null
    });

    console.log('Database seeded successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    process.exit(0);
  }
}

seedDatabase();