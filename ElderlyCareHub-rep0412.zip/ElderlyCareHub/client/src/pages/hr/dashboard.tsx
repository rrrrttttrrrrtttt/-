import React from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function HRDashboard() {
  const { user } = useAuth();

  // Fetch employees data
  const { data: employees, isLoading: isLoadingEmployees } = useQuery({
    queryKey: ["/api/employees"],
    queryFn: getQueryFn(),
  });

  // Recent activity data
  const { data: recentActivity, isLoading: isLoadingActivity } = useQuery({
    queryKey: ["/api/recent-activity"],
    queryFn: getQueryFn(),
  });

  return (
    <MainLayout>
      <div className="mb-4">
        <h1 className="text-2xl font-semibold text-neutral-800 dark:text-white">HR Management Dashboard</h1>
        <p className="text-neutral-500 dark:text-neutral-400">Overview of HR operations and metrics</p>
      </div>
      
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Total Employees */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Total Employees</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">128</p>
              </div>
              <div className="p-2 rounded-md bg-primary-light/10 text-primary dark:text-primary-light">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-green-600 dark:text-green-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
              </svg>
              <span>4.3% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Open Positions */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Open Positions</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">12</p>
              </div>
              <div className="p-2 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v3.57A22.952 22.952 0 0110 13a22.95 22.95 0 01-8-1.43V8a2 2 0 012-2h2zm2-1a1 1 0 011-1h2a1 1 0 011 1v1H8V5zm1 5a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-amber-600 dark:text-amber-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
              </svg>
              <span>2 new this week</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Upcoming Interviews */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Upcoming Interviews</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">8</p>
              </div>
              <div className="p-2 rounded-md bg-green-600/10 text-green-600 dark:text-green-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-green-600 dark:text-green-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
              </svg>
              <span>Next: Today at 14:00</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Time Off Requests */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Time Off Requests</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">5</p>
              </div>
              <div className="p-2 rounded-md bg-red-500/10 text-red-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zM12 2a1 1 0 01.967.744L14.146 7.2 17.5 9.134a1 1 0 010 1.732l-3.354 1.935-1.18 4.455a1 1 0 01-1.933 0L9.854 12.8 6.5 10.866a1 1 0 010-1.732l3.354-1.935 1.18-4.455A1 1 0 0112 2z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-red-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <span>3 pending approval</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activity and Employee Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="px-4 py-3 border-b border-neutral-200 dark:border-zinc-800 flex justify-between items-center">
              <CardTitle className="text-lg font-semibold text-neutral-800 dark:text-white">Recent Activity</CardTitle>
              <a href="#" className="text-sm text-primary dark:text-primary-light hover:underline">View All</a>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-4">
                {/* Activity Item 1 */}
                <div className="flex items-start">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Liu Mei" />
                    <AvatarFallback>LM</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="text-sm text-neutral-800 dark:text-white">
                      <span className="font-medium">Liu Mei</span> completed training on <span className="font-medium">Elderly Care Basics</span>
                    </p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Today at 10:34 AM</p>
                  </div>
                </div>
                
                {/* Activity Item 2 */}
                <div className="flex items-start">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Wang Jie" />
                    <AvatarFallback>WJ</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="text-sm text-neutral-800 dark:text-white">
                      <span className="font-medium">Wang Jie</span> submitted performance review for <span className="font-medium">Chen Hui</span>
                    </p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Yesterday at 15:22 PM</p>
                  </div>
                </div>
                
                {/* Activity Item 3 */}
                <div className="flex items-start">
                  <div className="h-10 w-10 mr-3 bg-primary text-white p-2 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M8 9a3 3 0 100-6 3 3 0 000 6zM8 11a6 6 0 016 6H2a6 6 0 016-6zM16 7a1 1 0 10-2 0v1h-1a1 1 0 100 2h1v1a1 1 0 102 0v-1h1a1 1 0 100-2h-1V7z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-neutral-800 dark:text-white">
                      <span className="font-medium">New application</span> received for <span className="font-medium">Senior Caregiver</span> position
                    </p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Yesterday at 11:05 AM</p>
                  </div>
                </div>
                
                {/* Activity Item 4 */}
                <div className="flex items-start">
                  <div className="h-10 w-10 mr-3 bg-green-500 text-white p-2 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-neutral-800 dark:text-white">
                      <span className="font-medium">Schedule</span> for next week has been approved
                    </p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">2 days ago</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Employee Status */}
        <div>
          <Card>
            <CardHeader className="px-4 py-3 border-b border-neutral-200 dark:border-zinc-800">
              <CardTitle className="text-lg font-semibold text-neutral-800 dark:text-white">Employee Status</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex flex-col">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Full-time</span>
                    <span className="text-sm text-neutral-500 dark:text-neutral-400">78</span>
                  </div>
                  <Progress value={60} className="h-2" />
                </div>
                
                <div className="flex flex-col">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Part-time</span>
                    <span className="text-sm text-neutral-500 dark:text-neutral-400">32</span>
                  </div>
                  <Progress value={25} className="h-2" />
                </div>
                
                <div className="flex flex-col">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Contract</span>
                    <span className="text-sm text-neutral-500 dark:text-neutral-400">18</span>
                  </div>
                  <Progress value={15} className="h-2" />
                </div>
                
                <div className="mt-6">
                  <h3 className="text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-3">Department Distribution</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-primary rounded-full mr-2"></div>
                        <span className="text-sm text-neutral-600 dark:text-neutral-400">Care Services</span>
                      </div>
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">42%</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                        <span className="text-sm text-neutral-600 dark:text-neutral-400">Administration</span>
                      </div>
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">28%</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-amber-500 rounded-full mr-2"></div>
                        <span className="text-sm text-neutral-600 dark:text-neutral-400">Facilities</span>
                      </div>
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">15%</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                        <span className="text-sm text-neutral-600 dark:text-neutral-400">Kitchen</span>
                      </div>
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">10%</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-neutral-400 rounded-full mr-2"></div>
                        <span className="text-sm text-neutral-600 dark:text-neutral-400">Other</span>
                      </div>
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">5%</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Recent Caregivers / Gig Workers */}
      <Card>
        <CardHeader className="px-4 py-3 border-b border-neutral-200 dark:border-zinc-800 flex justify-between items-center">
          <CardTitle className="text-lg font-semibold text-neutral-800 dark:text-white">Recent Caregivers</CardTitle>
          <div className="flex space-x-2">
            <a href="#" className="text-sm text-primary dark:text-primary-light hover:underline">Sync with Elderly Care</a>
            <a href="#" className="text-sm text-primary dark:text-primary-light hover:underline">View All</a>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full divide-y divide-neutral-200 dark:divide-zinc-800">
            <thead className="bg-neutral-50 dark:bg-zinc-900">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Position</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Joined</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-zinc-900 divide-y divide-neutral-200 dark:divide-zinc-800">
              {/* Employee 1 */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Zhang Xiu" />
                      <AvatarFallback>ZX</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-sm font-medium text-neutral-900 dark:text-white">Zhang Xiu</div>
                      <div className="text-sm text-neutral-500 dark:text-neutral-400">zhangxiu@example.com</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-neutral-900 dark:text-white">Senior Caregiver</div>
                  <div className="text-sm text-neutral-500 dark:text-neutral-400">Care Services</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                    Active
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                  2021-09-15
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <a href="#" className="text-primary dark:text-primary-light hover:text-primary-dark mr-3">View</a>
                  <a href="#" className="text-amber-500 hover:text-amber-600 mr-3">Edit</a>
                </td>
              </tr>
              
              {/* Employee 2 */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Li Wei" />
                      <AvatarFallback>LW</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-sm font-medium text-neutral-900 dark:text-white">Li Wei</div>
                      <div className="text-sm text-neutral-500 dark:text-neutral-400">liwei@example.com</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-neutral-900 dark:text-white">Caregiver</div>
                  <div className="text-sm text-neutral-500 dark:text-neutral-400">Care Services</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                    Active
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                  2022-01-05
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <a href="#" className="text-primary dark:text-primary-light hover:text-primary-dark mr-3">View</a>
                  <a href="#" className="text-amber-500 hover:text-amber-600 mr-3">Edit</a>
                </td>
              </tr>
              
              {/* Employee 3 */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Chen Hui" />
                      <AvatarFallback>CH</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-sm font-medium text-neutral-900 dark:text-white">Chen Hui</div>
                      <div className="text-sm text-neutral-500 dark:text-neutral-400">chenhui@example.com</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-neutral-900 dark:text-white">Caregiver</div>
                  <div className="text-sm text-neutral-500 dark:text-neutral-400">Care Services</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
                    Training
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                  2022-04-12
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <a href="#" className="text-primary dark:text-primary-light hover:text-primary-dark mr-3">View</a>
                  <a href="#" className="text-amber-500 hover:text-amber-600 mr-3">Edit</a>
                </td>
              </tr>
              
              {/* Employee 4 */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Wang Jie" />
                      <AvatarFallback>WJ</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-sm font-medium text-neutral-900 dark:text-white">Wang Jie</div>
                      <div className="text-sm text-neutral-500 dark:text-neutral-400">wangjie@example.com</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-neutral-900 dark:text-white">Care Coordinator</div>
                  <div className="text-sm text-neutral-500 dark:text-neutral-400">Management</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                    Active
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                  2020-11-30
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <a href="#" className="text-primary dark:text-primary-light hover:text-primary-dark mr-3">View</a>
                  <a href="#" className="text-amber-500 hover:text-amber-600 mr-3">Edit</a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </MainLayout>
  );
}
