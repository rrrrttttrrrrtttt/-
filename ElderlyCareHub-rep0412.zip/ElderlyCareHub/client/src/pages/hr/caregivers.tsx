import React, { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Loader2, Search, Plus, Filter, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";

export default function HRCaregivers() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  // Fetch caregivers data
  const { data: caregivers, isLoading } = useQuery({
    queryKey: ["/api/hr/caregivers"],
  });

  // Sync caregivers with elderly care system
  const syncMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/hr/caregivers/sync-with-elderly", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hr/caregivers"] });
      toast({
        title: "Sync completed",
        description: "Caregivers have been synchronized with the Elderly Care system.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Sync failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Filter caregivers based on search query
  const filteredCaregivers = caregivers ? caregivers.filter((caregiver: any) => 
    caregiver.user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    caregiver.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
    caregiver.user.email.toLowerCase().includes(searchQuery.toLowerCase())
  ) : [];

  return (
    <MainLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-neutral-800 dark:text-white">Caregivers</h1>
        <p className="text-neutral-500 dark:text-neutral-400">Manage caregivers and synchronize with Elderly Care system</p>
      </div>

      {/* Controls bar */}
      <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
        <div className="relative w-full md:w-auto md:flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral-500 dark:text-neutral-400" />
          <Input 
            placeholder="Search caregivers..." 
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="gap-1"
            onClick={() => syncMutation.mutate()}
            disabled={syncMutation.isPending}
          >
            {syncMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            Sync with Elderly Care
          </Button>

          <Dialog>
            <DialogTrigger asChild>
              <Button className="gap-1">
                <Plus className="h-4 w-4" />
                Add Caregiver
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Caregiver</DialogTitle>
                <DialogDescription>
                  Enter the details of the new caregiver below.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Full Name
                  </Label>
                  <Input id="name" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">
                    Email
                  </Label>
                  <Input id="email" type="email" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="position" className="text-right">
                    Position
                  </Label>
                  <Input id="position" defaultValue="Caregiver" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="experience" className="text-right">
                    Experience (Years)
                  </Label>
                  <Input id="experience" type="number" min="0" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="specialization" className="text-right">
                    Specialization
                  </Label>
                  <Input id="specialization" placeholder="e.g., Dementia Care" className="col-span-3" />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Save Caregiver</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Caregivers overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Total Caregivers</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">{caregivers?.length || 0}</p>
              </div>
              <div className="p-2 rounded-md bg-primary-light/10 text-primary dark:text-primary-light">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Active Shifts</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">14</p>
              </div>
              <div className="p-2 rounded-md bg-green-500/10 text-green-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Sync Status</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {syncMutation.isPending ? "Syncing..." : "In Sync"}
                </p>
              </div>
              <div className="p-2 rounded-md bg-blue-500/10 text-blue-500">
                <RefreshCw className={`h-5 w-5 ${syncMutation.isPending ? "animate-spin" : ""}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Caregivers table card */}
      <Card>
        <CardHeader className="px-6 py-4">
          <div className="flex justify-between items-center">
            <CardTitle>All Caregivers</CardTitle>
            <div className="text-sm text-neutral-500 dark:text-neutral-400">
              {filteredCaregivers.length} caregivers
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredCaregivers.length === 0 ? (
            <div className="text-center p-8 text-neutral-500 dark:text-neutral-400">
              {searchQuery ? "No caregivers found matching your search" : "No caregivers found. Add your first caregiver!"}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full divide-y divide-neutral-200 dark:divide-zinc-800">
                <thead className="bg-neutral-50 dark:bg-zinc-900">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Caregiver</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Position</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Elderly Care Integration</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-zinc-900 divide-y divide-neutral-200 dark:divide-zinc-800">
                  {filteredCaregivers.map((caregiver: any) => (
                    <tr key={caregiver.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={caregiver.user.avatar} alt={caregiver.user.fullName} />
                            <AvatarFallback>
                              {caregiver.user.fullName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="text-sm font-medium text-neutral-900 dark:text-white">{caregiver.user.fullName}</div>
                            <div className="text-sm text-neutral-500 dark:text-neutral-400">{caregiver.user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-900 dark:text-white">
                        {caregiver.position}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge variant="success">Active</Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        {caregiver.syncedWithElderly ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800">
                            Synchronized
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800">
                            Not Synchronized
                          </Badge>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <Button variant="ghost" size="sm" className="text-primary dark:text-primary-light hover:text-primary-dark dark:hover:text-primary-light mr-2">
                          View
                        </Button>
                        <Button variant="ghost" size="sm" className="text-primary dark:text-primary-light hover:text-primary-dark dark:hover:text-primary-light">
                          Edit
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </MainLayout>
  );
}
