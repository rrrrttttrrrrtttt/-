import React from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, RefreshCw } from "lucide-react";

export default function ElderlyDashboard() {
  const { user } = useAuth();

  // Fetch dashboard overview
  const { data: dashboardData, isLoading: isLoadingDashboard } = useQuery({
    queryKey: ["/api/elderly/dashboard"],
    queryFn: getQueryFn(),
  });

  // Fetch service records
  const { data: recentServiceRecords, isLoading: isLoadingServiceRecords } = useQuery({
    queryKey: ["/api/elderly/service-records/recent"],
    queryFn: getQueryFn(),
  });

  return (
    <MainLayout>
      <div className="mb-4">
        <h1 className="text-2xl font-semibold text-neutral-800 dark:text-white">Elderly Care Dashboard</h1>
        <p className="text-neutral-500 dark:text-neutral-400">Overview of elderly care services and residents</p>
      </div>
      
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Total Residents */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Total Residents</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoadingDashboard ? "..." : dashboardData?.totalResidents || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-primary-light/10 text-primary dark:text-primary-light">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-green-600 dark:text-green-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
              </svg>
              <span>2.7% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Active Services */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Active Services</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoadingDashboard ? "..." : dashboardData?.activeServices || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-green-500/10 text-green-600 dark:text-green-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4zm-6 3a1 1 0 112 0 1 1 0 01-2 0zm7-1a1 1 0 100 2 1 1 0 000-2z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-green-600 dark:text-green-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              <span>All services running</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Caregivers On Duty */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Caregivers On Duty</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoadingDashboard ? "..." : dashboardData?.caregiversOnDuty || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-amber-600 dark:text-amber-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <span>2 shifts understaffed</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Service Requests */}
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Service Requests</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoadingDashboard ? "..." : dashboardData?.pendingRequests || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-red-500/10 text-red-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
            <div className="mt-2 text-xs flex items-center text-red-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
              </svg>
              <span>3 pending for &gt;24h</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Service Performance and Resident Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Service Performance */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="px-4 py-3 border-b border-neutral-200 dark:border-zinc-800 flex justify-between items-center">
              <CardTitle className="text-lg font-semibold text-neutral-800 dark:text-white">Service Performance</CardTitle>
              <Select defaultValue="7days">
                <SelectTrigger className="w-36 h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 days</SelectItem>
                  <SelectItem value="30days">Last 30 days</SelectItem>
                  <SelectItem value="90days">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent className="p-4">
              {isLoadingDashboard ? (
                <div className="flex justify-center items-center h-60">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="space-y-5">
                  {/* Service Type 1 */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Daily Care</span>
                      <span className="text-sm text-green-600 dark:text-green-400 font-medium">97% satisfied</span>
                    </div>
                    <Progress value={97} className="h-2.5" />
                    <div className="flex justify-between mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                      <span>185 services completed</span>
                      <span>4 feedback received</span>
                    </div>
                  </div>
                  
                  {/* Service Type 2 */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Medication Management</span>
                      <span className="text-sm text-green-600 dark:text-green-400 font-medium">100% satisfied</span>
                    </div>
                    <Progress value={100} className="h-2.5" />
                    <div className="flex justify-between mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                      <span>210 services completed</span>
                      <span>6 feedback received</span>
                    </div>
                  </div>
                  
                  {/* Service Type 3 */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Mobility Assistance</span>
                      <span className="text-sm text-amber-600 dark:text-amber-400 font-medium">82% satisfied</span>
                    </div>
                    <Progress value={82} className="h-2.5 bg-neutral-200 dark:bg-neutral-700">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: "82%" }} />
                    </Progress>
                    <div className="flex justify-between mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                      <span>95 services completed</span>
                      <span>3 feedback received</span>
                    </div>
                  </div>
                  
                  {/* Service Type 4 */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Social Activities</span>
                      <span className="text-sm text-green-600 dark:text-green-400 font-medium">93% satisfied</span>
                    </div>
                    <Progress value={93} className="h-2.5" />
                    <div className="flex justify-between mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                      <span>42 services completed</span>
                      <span>5 feedback received</span>
                    </div>
                  </div>
                  
                  {/* Service Type 5 */}
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Meal Preparation</span>
                      <span className="text-sm text-amber-600 dark:text-amber-400 font-medium">78% satisfied</span>
                    </div>
                    <Progress value={78} className="h-2.5 bg-neutral-200 dark:bg-neutral-700">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: "78%" }} />
                    </Progress>
                    <div className="flex justify-between mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                      <span>125 services completed</span>
                      <span>8 feedback received</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Resident Status */}
        <div>
          <Card>
            <CardHeader className="px-4 py-3 border-b border-neutral-200 dark:border-zinc-800">
              <CardTitle className="text-lg font-semibold text-neutral-800 dark:text-white">Resident Status</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {isLoadingDashboard ? (
                <div className="flex justify-center items-center h-60">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-col">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Independent</span>
                      <span className="text-sm text-neutral-500 dark:text-neutral-400">98</span>
                    </div>
                    <Progress value={40} className="h-2">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: "40%" }} />
                    </Progress>
                  </div>
                  
                  <div className="flex flex-col">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Partially Dependent</span>
                      <span className="text-sm text-neutral-500 dark:text-neutral-400">112</span>
                    </div>
                    <Progress value={46} className="h-2 bg-neutral-200 dark:bg-neutral-700">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: "46%" }} />
                    </Progress>
                  </div>
                  
                  <div className="flex flex-col">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Fully Dependent</span>
                      <span className="text-sm text-neutral-500 dark:text-neutral-400">35</span>
                    </div>
                    <Progress value={14} className="h-2 bg-neutral-200 dark:bg-neutral-700">
                      <div className="h-full bg-red-500 rounded-full" style={{ width: "14%" }} />
                    </Progress>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-3">Care Level Distribution</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-primary rounded-full mr-2"></div>
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">Basic Care</span>
                        </div>
                        <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">55%</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">Medium Care</span>
                        </div>
                        <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">30%</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-amber-500 rounded-full mr-2"></div>
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">High Care</span>
                        </div>
                        <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">15%</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-3">Age Distribution</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-primary rounded-full mr-2"></div>
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">65-75</span>
                        </div>
                        <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">28%</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">76-85</span>
                        </div>
                        <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">42%</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-amber-500 rounded-full mr-2"></div>
                          <span className="text-sm text-neutral-600 dark:text-neutral-400">86+</span>
                        </div>
                        <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">30%</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Recent Service Records */}
      <Card>
        <CardHeader className="px-4 py-3 border-b border-neutral-200 dark:border-zinc-800 flex justify-between items-center">
          <CardTitle className="text-lg font-semibold text-neutral-800 dark:text-white">Recent Service Records</CardTitle>
          <div className="flex space-x-2">
            <a href="#" className="text-sm text-primary dark:text-primary-light hover:underline flex items-center gap-1">
              <RefreshCw className="h-3 w-3" />
              Sync with HR
            </a>
            <a href="/elderly/service-records" className="text-sm text-primary dark:text-primary-light hover:underline">View All</a>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          {isLoadingServiceRecords ? (
            <div className="flex justify-center items-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <table className="w-full divide-y divide-neutral-200 dark:divide-zinc-800">
              <thead className="bg-neutral-50 dark:bg-zinc-900">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Resident</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Service</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Caregiver</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-zinc-900 divide-y divide-neutral-200 dark:divide-zinc-800">
                {recentServiceRecords?.map((record: any) => (
                  <tr key={record.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarImage src={record.resident.avatar} alt={record.resident.fullName} />
                          <AvatarFallback>
                            {record.resident.fullName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="text-sm font-medium text-neutral-900 dark:text-white">{record.resident.fullName}</div>
                          <div className="text-sm text-neutral-500 dark:text-neutral-400">Room {record.resident.roomNumber}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-neutral-900 dark:text-white">{record.service.name}</div>
                      <div className="text-sm text-neutral-500 dark:text-neutral-400">{record.service.frequency}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {record.employee ? (
                        <div>
                          <div className="text-sm text-neutral-900 dark:text-white">{record.employee.user.fullName}</div>
                          <div className="text-sm text-neutral-500 dark:text-neutral-400">{record.employee.position}</div>
                        </div>
                      ) : (
                        <div className="text-sm text-neutral-500 dark:text-neutral-400">Not Assigned</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                      {new Date(record.scheduledTime).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Badge 
                        variant={
                          record.status === "completed" ? "success" : 
                          record.status === "in_progress" ? "warning" : 
                          record.status === "not_assigned" ? "destructive" : 
                          "outline"
                        }
                      >
                        {record.status === "completed" ? "Completed" : 
                         record.status === "in_progress" ? "In Progress" : 
                         record.status === "not_assigned" ? "Not Assigned" : 
                         record.status === "cancelled" ? "Cancelled" : record.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <a href={`/elderly/service-records/${record.id}`} className="text-primary dark:text-primary-light hover:text-primary-dark mr-3">View</a>
                      <a href={`/elderly/service-records/${record.id}/edit`} className="text-amber-500 hover:text-amber-600 mr-3">Edit</a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </Card>
    </MainLayout>
  );
}
