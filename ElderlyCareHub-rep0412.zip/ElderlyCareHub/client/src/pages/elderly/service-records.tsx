import React, { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Loader2, Search, Plus, Filter, RefreshCw, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

export default function ServiceRecords() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();
  
  // Fetch service records
  const { data: serviceRecords, isLoading } = useQuery({
    queryKey: ["/api/elderly/service-records"],
  });

  // Fetch residents (for creating a new service record)
  const { data: residents } = useQuery({
    queryKey: ["/api/elderly/residents"],
  });

  // Fetch services (for creating a new service record)
  const { data: services } = useQuery({
    queryKey: ["/api/elderly/services"],
  });

  // Fetch caregivers (for creating a new service record)
  const { data: caregivers } = useQuery({
    queryKey: ["/api/elderly/caregivers"],
  });

  // Create service record mutation
  const createRecordMutation = useMutation({
    mutationFn: async (data: any) => {
      return await fetch("/api/elderly/service-records", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/elderly/service-records"] });
      toast({
        title: "Service record created",
        description: "The service record has been successfully created.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create service record",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Filter service records based on search query and status
  const filteredRecords = serviceRecords ? serviceRecords.filter((record: any) => {
    const matchesSearch = 
      record.resident.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (record.employee?.user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) || false);
    
    const matchesStatus = 
      statusFilter === "all" || 
      record.status === statusFilter;
      
    return matchesSearch && matchesStatus;
  }) : [];

  // Function to format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  // Handle the submit of the new service record form
  const handleSubmitServiceRecord = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      residentId: Number(formData.get("residentId")),
      serviceId: Number(formData.get("serviceId")),
      employeeId: formData.get("employeeId") ? Number(formData.get("employeeId")) : null,
      scheduledTime: formData.get("scheduledTime"),
      status: formData.get("status"),
      notes: formData.get("notes"),
    };
    
    createRecordMutation.mutate(data);
  };

  return (
    <MainLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-neutral-800 dark:text-white">Service Records</h1>
        <p className="text-neutral-500 dark:text-neutral-400">Manage and track care services provided to residents</p>
      </div>

      {/* Controls bar */}
      <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
        <div className="relative w-full md:w-auto md:flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral-500 dark:text-neutral-400" />
          <Input 
            placeholder="Search service records..." 
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Select 
            defaultValue="all"
            onValueChange={setStatusFilter}
          >
            <SelectTrigger className="w-[180px]">
              <div className="flex items-center">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="All Statuses" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="not_assigned">Not Assigned</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>

          <Dialog>
            <DialogTrigger asChild>
              <Button className="gap-1">
                <Plus className="h-4 w-4" />
                New Service Record
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create New Service Record</DialogTitle>
                <DialogDescription>
                  Fill in the details to schedule a new service for a resident.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmitServiceRecord}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="residentId" className="text-right">
                      Resident
                    </Label>
                    <Select name="residentId" required>
                      <SelectTrigger className="col-span-3" id="residentId">
                        <SelectValue placeholder="Select a resident" />
                      </SelectTrigger>
                      <SelectContent>
                        {residents?.map((resident: any) => (
                          <SelectItem key={resident.id} value={resident.id.toString()}>
                            {resident.fullName} (Room {resident.roomNumber})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="serviceId" className="text-right">
                      Service
                    </Label>
                    <Select name="serviceId" required>
                      <SelectTrigger className="col-span-3" id="serviceId">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent>
                        {services?.map((service: any) => (
                          <SelectItem key={service.id} value={service.id.toString()}>
                            {service.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="employeeId" className="text-right">
                      Caregiver
                    </Label>
                    <Select name="employeeId">
                      <SelectTrigger className="col-span-3" id="employeeId">
                        <SelectValue placeholder="Assign a caregiver (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        {caregivers?.map((caregiver: any) => (
                          <SelectItem key={caregiver.id} value={caregiver.id.toString()}>
                            {caregiver.user.fullName} ({caregiver.position})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="scheduledTime" className="text-right">
                      Schedule
                    </Label>
                    <div className="col-span-3 relative">
                      <Calendar className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral-500 dark:text-neutral-400" />
                      <Input 
                        id="scheduledTime" 
                        name="scheduledTime"
                        type="datetime-local"
                        className="pl-9"
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="status" className="text-right">
                      Status
                    </Label>
                    <Select name="status" defaultValue="not_assigned" required>
                      <SelectTrigger className="col-span-3" id="status">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="not_assigned">Not Assigned</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-start gap-4">
                    <Label htmlFor="notes" className="text-right pt-2">
                      Notes
                    </Label>
                    <Textarea 
                      id="notes" 
                      name="notes"
                      placeholder="Add any relevant notes about this service"
                      className="col-span-3 min-h-[80px]"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createRecordMutation.isPending}>
                    {createRecordMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      "Create Service Record"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Service records stats overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Total Records</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoading ? "..." : serviceRecords?.length || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-primary-light/10 text-primary dark:text-primary-light">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Completed</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoading ? "..." : serviceRecords?.filter((r: any) => r.status === "completed").length || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-green-500/10 text-green-600 dark:text-green-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">In Progress</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoading ? "..." : serviceRecords?.filter((r: any) => r.status === "in_progress").length || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Not Assigned</p>
                <p className="text-2xl font-semibold mt-1 text-neutral-800 dark:text-white">
                  {isLoading ? "..." : serviceRecords?.filter((r: any) => r.status === "not_assigned").length || 0}
                </p>
              </div>
              <div className="p-2 rounded-md bg-red-500/10 text-red-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Service records table */}
      <Card>
        <CardHeader className="px-6 py-4">
          <div className="flex justify-between items-center">
            <Tabs defaultValue="upcoming" className="w-full">
              <div className="flex justify-between items-center">
                <TabsList>
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="past">Past</TabsTrigger>
                  <TabsTrigger value="all">All Records</TabsTrigger>
                </TabsList>
                <div className="text-sm text-neutral-500 dark:text-neutral-400">
                  {filteredRecords.length} records
                </div>
              </div>
              <TabsContent value="upcoming" className="mt-0">
                {renderServiceRecordsTable(filteredRecords.filter((r: any) => 
                  new Date(r.scheduledTime) > new Date() && 
                  r.status !== "completed" && 
                  r.status !== "cancelled"
                ), isLoading, searchQuery, statusFilter)}
              </TabsContent>
              <TabsContent value="past" className="mt-0">
                {renderServiceRecordsTable(filteredRecords.filter((r: any) => 
                  new Date(r.scheduledTime) < new Date() || 
                  r.status === "completed" || 
                  r.status === "cancelled"
                ), isLoading, searchQuery, statusFilter)}
              </TabsContent>
              <TabsContent value="all" className="mt-0">
                {renderServiceRecordsTable(filteredRecords, isLoading, searchQuery, statusFilter)}
              </TabsContent>
            </Tabs>
          </div>
        </CardHeader>
      </Card>
    </MainLayout>
  );

  // Helper function to render the service records table
  function renderServiceRecordsTable(records: any[], isLoading: boolean, searchQuery: string, statusFilter: string) {
    return (
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex justify-center items-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : records.length === 0 ? (
          <div className="text-center p-8 text-neutral-500 dark:text-neutral-400">
            {searchQuery || statusFilter !== "all" 
              ? "No service records found matching your filters" 
              : "No service records found. Create your first record!"}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full divide-y divide-neutral-200 dark:divide-zinc-800">
              <thead className="bg-neutral-50 dark:bg-zinc-900">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Resident</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Service</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Caregiver</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-zinc-900 divide-y divide-neutral-200 dark:divide-zinc-800">
                {records.map((record: any) => (
                  <tr key={record.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarImage src={record.resident.avatar} alt={record.resident.fullName} />
                          <AvatarFallback>
                            {record.resident.fullName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="text-sm font-medium text-neutral-900 dark:text-white">{record.resident.fullName}</div>
                          <div className="text-sm text-neutral-500 dark:text-neutral-400">Room {record.resident.roomNumber}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-neutral-900 dark:text-white">{record.service.name}</div>
                      <div className="text-sm text-neutral-500 dark:text-neutral-400">{record.service.frequency}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {record.employee ? (
                        <div className="flex items-center">
                          <Avatar className="h-8 w-8 mr-2">
                            <AvatarImage src={record.employee.user.avatar} alt={record.employee.user.fullName} />
                            <AvatarFallback>
                              {record.employee.user.fullName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="text-sm text-neutral-900 dark:text-white">{record.employee.user.fullName}</div>
                            <div className="text-sm text-neutral-500 dark:text-neutral-400">{record.employee.position}</div>
                          </div>
                        </div>
                      ) : (
                        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800">
                          Not Assigned
                        </Badge>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                      {formatDate(record.scheduledTime)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Badge 
                        variant={
                          record.status === "completed" ? "success" : 
                          record.status === "in_progress" ? "warning" : 
                          record.status === "not_assigned" ? "destructive" : 
                          "outline"
                        }
                      >
                        {record.status === "completed" ? "Completed" : 
                         record.status === "in_progress" ? "In Progress" : 
                         record.status === "not_assigned" ? "Not Assigned" : 
                         record.status === "cancelled" ? "Cancelled" : record.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <Button variant="ghost" size="sm" className="text-primary dark:text-primary-light hover:text-primary-dark dark:hover:text-primary-light mr-2">
                        View
                      </Button>
                      <Button variant="ghost" size="sm" className="text-primary dark:text-primary-light hover:text-primary-dark dark:hover:text-primary-light">
                        {record.status === "not_assigned" ? "Assign" : "Edit"}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    );
  }
}
