import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

type ProtectedRouteProps = {
  path: string;
  component: React.ComponentType<any>;
  allowedRoles: string[];
};

export function ProtectedRoute({ path, component: Component, allowedRoles }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Route>
    );
  }

  return (
    <Route path={path}>
      {() => {
        // If user is not logged in, redirect to auth page
        if (!user) {
          return <Redirect to="/auth" />;
        }

        // If user role is not allowed, redirect to appropriate dashboard
        if (!allowedRoles.includes(user.role)) {
          if (user.role === "hr_admin") {
            return <Redirect to="/hr/dashboard" />;
          } else if (user.role === "elderly_admin") {
            return <Redirect to="/elderly/dashboard" />;
          } else {
            return <Redirect to="/auth" />;
          }
        }

        // If all checks pass, render the component
        return <Component />;
      }}
    </Route>
  );
}
