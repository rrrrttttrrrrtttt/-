import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

// HR Pages
import HRDashboard from "@/pages/hr/dashboard";
import Employees from "@/pages/hr/employees";
import HRCaregivers from "@/pages/hr/caregivers";

// Elderly Care Pages
import ElderlyCaregivers from "@/pages/elderly/caregivers";
import ElderlyDashboard from "@/pages/elderly/dashboard";
import Residents from "@/pages/elderly/residents";
import ServiceRecords from "@/pages/elderly/service-records";

function Router() {
  return (
    <Switch>
      {/* Auth routes */}
      <Route path="/auth" component={AuthPage} />
      
      {/* HR Routes - protected with HR role */}
      <Route path="/hr">
        <ProtectedRoute path="/hr" component={HRDashboard} allowedRoles={["hr_admin"]} />
        <ProtectedRoute path="/hr/dashboard" component={HRDashboard} allowedRoles={["hr_admin"]} />
        <ProtectedRoute path="/hr/employees" component={Employees} allowedRoles={["hr_admin"]} />
        <ProtectedRoute path="/hr/caregivers" component={HRCaregivers} allowedRoles={["hr_admin"]} />
      </Route>
      
      {/* Elderly Care Routes - protected with Elderly role */}
      <Route path="/elderly">
        <ProtectedRoute path="/elderly" component={ElderlyDashboard} allowedRoles={["elderly_admin"]} />
        <ProtectedRoute path="/elderly/dashboard" component={ElderlyDashboard} allowedRoles={["elderly_admin"]} />
        <ProtectedRoute path="/elderly/residents" component={Residents} allowedRoles={["elderly_admin"]} />
        <ProtectedRoute path="/elderly/caregivers" component={ElderlyCaregivers} allowedRoles={["elderly_admin"]} />
        <ProtectedRoute path="/elderly/service-records" component={ServiceRecords} allowedRoles={["elderly_admin"]} />
      </Route>

      {/* Redirect root to appropriate dashboard based on role */}
      <ProtectedRoute path="/" component={() => <RedirectByRole />} allowedRoles={["hr_admin", "elderly_admin"]} />
      
      {/* Fallback - catch all unmatched routes */}
      <Route path="/:rest*" component={NotFound} />
    </Switch>
  );
}

// Helper component to redirect users based on their role
function RedirectByRole() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  React.useEffect(() => {
    if (user) {
      const redirectPath = user.role === "hr_admin" ? "/hr/dashboard" : "/elderly/dashboard";
      navigate(redirectPath);
    }
  }, [user, navigate]);

  return null;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
