import React from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  IconDashboard,
  IconEmployees,
  IconCaregivers,
  IconResidents,
  IconServices,
  IconRecords,
  IconSettings,
  IconIntegration
} from "../ui/icons";
import { cn } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface SidebarProps {
  isCollapsed: boolean;
}

export function Sidebar({ isCollapsed }: SidebarProps) {
  const [location] = useLocation();
  const { isPlatformHR, setIsPlatformHR } = useAuth();

  // Function to switch platform
  const switchPlatform = (platform: string) => {
    if (platform === "hr") {
      setIsPlatformHR(true);
    } else {
      setIsPlatformHR(false);
    }
  };

  // Function to determine if a link is active
  const isLinkActive = (path: string) => {
    return location === path || location.startsWith(`${path}/`);
  };

  return (
    <aside 
      className={cn(
        "bg-white dark:bg-zinc-900 border-r border-neutral-200 dark:border-zinc-800 h-screen overflow-y-auto transition-all duration-300 fixed lg:static z-20",
        isCollapsed ? "w-16" : "w-64"
      )}
    >
      {/* Mobile Platform Switcher */}
      <div className="px-4 py-3 border-b border-neutral-200 dark:border-zinc-800 lg:hidden">
        <Select onValueChange={switchPlatform} defaultValue={isPlatformHR ? "hr" : "elderly"}>
          <SelectTrigger className="w-full bg-neutral-100 dark:bg-zinc-800 border border-neutral-200 dark:border-zinc-700 text-sm">
            <SelectValue placeholder="Select Platform" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hr">HR Management</SelectItem>
            <SelectItem value="elderly">Elderly Care</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* HR Management Sidebar Content */}
      {isPlatformHR && (
        <div className="py-4">
          <nav className="space-y-1 px-2">
            <Link href="/hr/dashboard">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/hr/dashboard") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconDashboard />
                {!isCollapsed && <span className="ml-3">Dashboard</span>}
              </a>
            </Link>
            
            <Link href="/hr/employees">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/hr/employees") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconEmployees />
                {!isCollapsed && <span className="ml-3">Employees</span>}
              </a>
            </Link>
            
            <Link href="/hr/caregivers">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/hr/caregivers") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconCaregivers />
                {!isCollapsed && <span className="ml-3">Caregivers</span>}
              </a>
            </Link>
            
            <Link href="/hr/recruitment">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/hr/recruitment") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M8 9a3 3 0 100-6 3 3 0 000 6zM8 11a6 6 0 016 6H2a6 6 0 016-6zM16 7a1 1 0 10-2 0v1h-1a1 1 0 100 2h1v1a1 1 0 102 0v-1h1a1 1 0 100-2h-1V7z" />
                </svg>
                {!isCollapsed && <span className="ml-3">Recruitment</span>}
              </a>
            </Link>
            
            <Link href="/hr/scheduling">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/hr/scheduling") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                </svg>
                {!isCollapsed && <span className="ml-3">Scheduling</span>}
              </a>
            </Link>
            
            <div className="pt-4 mt-4 border-t border-neutral-200 dark:border-zinc-800">
              {!isCollapsed && (
                <h3 className="px-3 text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                  System
                </h3>
              )}
              
              <div className="mt-2 space-y-1">
                <Link href="/hr/settings">
                  <a className={cn(
                    "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                    isLinkActive("/hr/settings") 
                      ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                      : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
                  )}>
                    <IconSettings />
                    {!isCollapsed && <span className="ml-3">Settings</span>}
                  </a>
                </Link>
                
                <Link href="/hr/integrations">
                  <a className={cn(
                    "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                    isLinkActive("/hr/integrations") 
                      ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                      : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
                  )}>
                    <IconIntegration />
                    {!isCollapsed && <span className="ml-3">Integrations</span>}
                  </a>
                </Link>
              </div>
            </div>
          </nav>
        </div>
      )}
      
      {/* Elderly Care Sidebar Content */}
      {!isPlatformHR && (
        <div className="py-4">
          <nav className="space-y-1 px-2">
            <Link href="/elderly/dashboard">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/elderly/dashboard") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconDashboard />
                {!isCollapsed && <span className="ml-3">Dashboard</span>}
              </a>
            </Link>
            
            <Link href="/elderly/residents">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/elderly/residents") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconResidents />
                {!isCollapsed && <span className="ml-3">Residents</span>}
              </a>
            </Link>
            
            <Link href="/elderly/services">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/elderly/services") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconServices />
                {!isCollapsed && <span className="ml-3">Services</span>}
              </a>
            </Link>
            
            <Link href="/elderly/caregivers">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/elderly/caregivers") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconCaregivers />
                {!isCollapsed && <span className="ml-3">Caregivers</span>}
              </a>
            </Link>
            
            <Link href="/elderly/service-records">
              <a className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                isLinkActive("/elderly/service-records") 
                  ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                  : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
              )}>
                <IconRecords />
                {!isCollapsed && <span className="ml-3">Service Records</span>}
              </a>
            </Link>
            
            <div className="pt-4 mt-4 border-t border-neutral-200 dark:border-zinc-800">
              {!isCollapsed && (
                <h3 className="px-3 text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                  System
                </h3>
              )}
              
              <div className="mt-2 space-y-1">
                <Link href="/elderly/settings">
                  <a className={cn(
                    "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                    isLinkActive("/elderly/settings") 
                      ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                      : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
                  )}>
                    <IconSettings />
                    {!isCollapsed && <span className="ml-3">Settings</span>}
                  </a>
                </Link>
                
                <Link href="/elderly/hr-integration">
                  <a className={cn(
                    "flex items-center px-3 py-2 rounded-md text-sm font-medium",
                    isLinkActive("/elderly/hr-integration") 
                      ? "bg-primary-light/10 text-primary dark:text-primary-light" 
                      : "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-zinc-800"
                  )}>
                    <IconIntegration />
                    {!isCollapsed && <span className="ml-3">HR Integration</span>}
                  </a>
                </Link>
              </div>
            </div>
          </nav>
        </div>
      )}
    </aside>
  );
}
