import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { IconLogo, IconHR, IconElderly, IconMenu, IconNotification, IconDarkMode, IconLightMode } from "../ui/icons";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  toggleSidebar: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export function Header({ toggleSidebar, isDarkMode, toggleDarkMode }: HeaderProps) {
  const { user, logoutMutation, isPlatformHR, setIsPlatformHR } = useAuth();
  const [hasNotifications, setHasNotifications] = useState(true);

  const switchToHR = () => {
    setIsPlatformHR(true);
  };

  const switchToElderly = () => {
    setIsPlatformHR(false);
  };

  return (
    <header className="bg-white dark:bg-zinc-900 shadow-sm border-b border-neutral-200 dark:border-zinc-800">
      <div className="flex items-center justify-between px-4 py-2">
        {/* Logo and Platform Switcher */}
        <div className="flex items-center">
          {/* Menu toggle button */}
          <Button 
            variant="ghost" 
            onClick={toggleSidebar} 
            className="p-2 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-zinc-800 mr-2 lg:hidden"
          >
            <IconMenu />
          </Button>
          
          {/* Logo */}
          <div className="flex items-center">
            <div className="text-primary">
              <IconLogo />
            </div>
            <span className="ml-2 text-lg font-semibold text-primary dark:text-primary-light hidden md:inline-block">
              Enterprise Platform
            </span>
          </div>
          
          {/* Platform Switcher */}
          <div className="hidden lg:flex items-center ml-8">
            {/* HR Management */}
            <Button 
              variant={isPlatformHR ? "default" : "ghost"}
              className={`px-4 py-2 rounded-md font-medium transition-colors duration-200`}
              onClick={switchToHR}
            >
              <IconHR />
              HR Management
            </Button>
            
            {/* Elderly Care */}
            <Button 
              variant={!isPlatformHR ? "default" : "ghost"}
              className={`px-4 py-2 rounded-md font-medium transition-colors duration-200`}
              onClick={switchToElderly}
            >
              <IconElderly />
              Elderly Care
            </Button>
          </div>
        </div>
        
        {/* Right side controls */}
        <div className="flex items-center space-x-2">
          {/* Notifications */}
          <Button variant="ghost" className="p-2 rounded-full text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-zinc-800 relative">
            <IconNotification />
            {hasNotifications && (
              <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full"></span>
            )}
          </Button>
          
          {/* Dark mode toggle */}
          <Button 
            variant="ghost" 
            onClick={toggleDarkMode} 
            className="p-2 rounded-full text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-zinc-800"
          >
            {isDarkMode ? <IconLightMode /> : <IconDarkMode />}
          </Button>
          
          {/* User profile */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-2 p-1 rounded-md hover:bg-neutral-100 dark:hover:bg-zinc-800">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user?.avatar} alt={user?.fullName || "User"} />
                  <AvatarFallback className="bg-primary text-white">
                    {user?.fullName?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col text-left hidden md:block">
                  <span className="text-sm font-medium">{user?.fullName || "User"}</span>
                  <span className="text-xs text-neutral-500 dark:text-neutral-400">
                    {user?.role === "hr_admin" ? "HR Administrator" : "Elderly Care Admin"}
                  </span>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <Link href="/profile">
                <DropdownMenuItem className="cursor-pointer">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                  View Profile
                </DropdownMenuItem>
              </Link>
              <Link href="/settings">
                <DropdownMenuItem className="cursor-pointer">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                  </svg>
                  Settings
                </DropdownMenuItem>
              </Link>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="cursor-pointer text-red-500 focus:text-red-500" 
                onClick={() => logoutMutation.mutate()}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V4a1 1 0 00-1-1H3zm1 2v10h10V5H4zm5 4a1 1 0 10-2 0v2a1 1 0 102 0V9zm4-1a1 1 0 011 1v2a1 1 0 11-2 0V9a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
                Sign Out
                {logoutMutation.isPending && <span className="ml-2">...</span>}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
