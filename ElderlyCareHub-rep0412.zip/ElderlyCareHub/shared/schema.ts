import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enum definitions
export const userRoleEnum = pgEnum('user_role', ['hr_admin', 'elderly_admin', 'caregiver', 'worker']);
export const employmentTypeEnum = pgEnum('employment_type', ['full_time', 'part_time', 'contract']);
export const careServiceStatusEnum = pgEnum('care_service_status', ['completed', 'in_progress', 'not_assigned', 'cancelled']);
export const residentStatusEnum = pgEnum('resident_status', ['independent', 'partially_dependent', 'fully_dependent']);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  role: userRoleEnum("role").notNull(),
  avatar: text("avatar"),
});

// Employees table
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  position: text("position").notNull(),
  department: text("department").notNull(),
  employmentType: employmentTypeEnum("employment_type").notNull(),
  joinDate: timestamp("join_date").notNull(),
  isCaregiver: boolean("is_caregiver").default(false),
});

// Residents table
export const residents = pgTable("residents", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  roomNumber: text("room_number"),
  age: integer("age").notNull(),
  status: residentStatusEnum("status").notNull(),
  careLevel: text("care_level").notNull(),
  avatar: text("avatar"),
});

// Care services table
export const careServices = pgTable("care_services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  frequency: text("frequency"),
  defaultDuration: integer("default_duration"),
});

// Service records table
export const serviceRecords = pgTable("service_records", {
  id: serial("id").primaryKey(),
  residentId: integer("resident_id").references(() => residents.id),
  serviceId: integer("service_id").references(() => careServices.id),
  employeeId: integer("employee_id").references(() => employees.id),
  status: careServiceStatusEnum("status").notNull(),
  scheduledTime: timestamp("scheduled_time").notNull(),
  completedTime: timestamp("completed_time"),
  notes: text("notes"),
  feedback: text("feedback"),
  rating: integer("rating"),
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  employees: many(employees),
}));

export const employeesRelations = relations(employees, ({ one, many }) => ({
  user: one(users, { fields: [employees.userId], references: [users.id] }),
  serviceRecords: many(serviceRecords),
}));

export const residentsRelations = relations(residents, ({ many }) => ({
  serviceRecords: many(serviceRecords),
}));

export const careServicesRelations = relations(careServices, ({ many }) => ({
  serviceRecords: many(serviceRecords),
}));

export const serviceRecordsRelations = relations(serviceRecords, ({ one }) => ({
  resident: one(residents, { fields: [serviceRecords.residentId], references: [residents.id] }),
  service: one(careServices, { fields: [serviceRecords.serviceId], references: [careServices.id] }),
  employee: one(employees, { fields: [serviceRecords.employeeId], references: [employees.id] }),
}));

// Schema definitions
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
});

export const insertResidentSchema = createInsertSchema(residents).omit({
  id: true,
});

export const insertCareServiceSchema = createInsertSchema(careServices).omit({
  id: true,
});

export const insertServiceRecordSchema = createInsertSchema(serviceRecords).omit({
  id: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;

export type Resident = typeof residents.$inferSelect;
export type InsertResident = z.infer<typeof insertResidentSchema>;

export type CareService = typeof careServices.$inferSelect;
export type InsertCareService = z.infer<typeof insertCareServiceSchema>;

export type ServiceRecord = typeof serviceRecords.$inferSelect;
export type InsertServiceRecord = z.infer<typeof insertServiceRecordSchema>;

// Combined types for API responses
export type EmployeeWithUser = Employee & {
  user: User;
};

export type ServiceRecordDetails = ServiceRecord & {
  resident: Resident;
  service: CareService;
  employee?: EmployeeWithUser;
};

// Auth-related types
export type LoginCredentials = Pick<User, 'username' | 'password'>;
