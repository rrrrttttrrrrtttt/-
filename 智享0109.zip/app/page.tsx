"use client"

import BrainShareApp from "../brain-share-app"

export default function SyntheticV0PageForDeployment() {
  return <BrainShareApp />
}