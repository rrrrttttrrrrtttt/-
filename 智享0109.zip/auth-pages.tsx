import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface AuthProps {
  onLogin: (phone: string, code: string) => void
  onRegister: (phone: string) => void
  onToggle: () => void
  isLogin: boolean
}

export function AuthPages({ onLogin, onRegister, onToggle, isLogin }: AuthProps) {
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [codeSent, setCodeSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (isLogin) {
      if (codeSent) {
        onLogin(phone, code)
      } else {
        // 在实际应用中，这里会发送验证码
        console.log('正在发送验证码到', phone)
        setCodeSent(true)
      }
    } else {
      onRegister(phone)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{isLogin ? '登录' : '注册'}</CardTitle>
        <CardDescription>
          {isLogin ? '欢迎回来！请登录您的账户。' : '创建一个新账户以开始使用。'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="phone">手机号码</Label>
            <Input 
              id="phone" 
              type="tel" 
              placeholder="输入您的手机号码" 
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </div>
          {isLogin && codeSent && (
            <div className="space-y-2">
              <Label htmlFor="code">验证码</Label>
              <Input 
                id="code" 
                type="text" 
                placeholder="输入验证码" 
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
              />
            </div>
          )}
          <Button type="submit" className="w-full">
            {isLogin 
              ? (codeSent ? '登录' : '发送验证码')
              : '注册'
            }
          </Button>
        </form>
      </CardContent>
      <CardFooter>
        <Button variant="link" onClick={onToggle}>
          {isLogin ? "没有账户？注册" : "已有账户？登录"}
        </Button>
      </CardFooter>
    </Card>
  )
}

